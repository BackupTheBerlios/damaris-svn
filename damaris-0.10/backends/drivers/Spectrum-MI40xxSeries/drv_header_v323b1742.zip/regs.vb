Option Strict Off
Option Explicit On
Module c_header\regs
' Spectrum C/C++ header file -> Basic file converter
' Source file:
' ***********************************************************************
'
' regs.h                                          (c) Spectrum GmbH, 2006
'
' ***********************************************************************
'
' software register and constants definition for all Spectrum drivers. 
' Please stick to the card manual to see which of the inhere defined 
' registers are used on your hardware.
'          
' ***********************************************************************



' ***********************************************************************
' macros for kilo, Mega or Giga as standard version or binary (_B) (2^x)
' ***********************************************************************





' ***********************************************************************
' card types
' ***********************************************************************

Public Const TYP_PCIDEVICEID             As Integer = &H00000000

' ***** Board Types ***************
Public Const TYP_EVAL                    As Integer = &H00000010
Public Const TYP_RSDLGA                  As Integer = &H00000014
Public Const TYP_GMG                     As Integer = &H00000018
Public Const TYP_VAN8                    As Integer = &H00000020
Public Const TYP_VAC                     As Integer = &H00000028

Public Const TYP_PCIAUTOINSTALL          As Integer = &H000000FF

Public Const TYP_DAP116                  As Integer = &H00000100
Public Const TYP_PAD82                   As Integer = &H00000200
Public Const TYP_PAD82a                  As Integer = &H00000210
Public Const TYP_PAD82b                  As Integer = &H00000220
Public Const TYP_PCI212                  As Integer = &H00000300
Public Const TYP_PAD1232a                As Integer = &H00000400
Public Const TYP_PAD1232b                As Integer = &H00000410
Public Const TYP_PAD1232c                As Integer = &H00000420
Public Const TYP_PAD1616a                As Integer = &H00000500
Public Const TYP_PAD1616b                As Integer = &H00000510
Public Const TYP_PAD1616c                As Integer = &H00000520
Public Const TYP_PAD1616d                As Integer = &H00000530
Public Const TYP_PAD52                   As Integer = &H00000600
Public Const TYP_PAD242                  As Integer = &H00000700
Public Const TYP_PCK400                  As Integer = &H00000800
Public Const TYP_PAD164_2M               As Integer = &H00000900
Public Const TYP_PAD164_5M               As Integer = &H00000910
Public Const TYP_PCI208                  As Integer = &H00001000
Public Const TYP_CPCI208                 As Integer = &H00001001
Public Const TYP_PCI412                  As Integer = &H00001100
Public Const TYP_PCIDIO32                As Integer = &H00001200
Public Const TYP_PCI248                  As Integer = &H00001300
Public Const TYP_PADCO                   As Integer = &H00001400
Public Const TYP_TRS582                  As Integer = &H00001500
Public Const TYP_PCI258                  As Integer = &H00001600


' ------ series and familiy identifiers -----
Public Const TYP_SERIESMASK              As Integer = &H00FF0000     ' the series (= type of base card), e.g. MI.xxxx
Public Const TYP_VERSIONMASK             As Integer = &H0000FFFF     ' the version, e.g. XX.3012
Public Const TYP_FAMILYMASK              As Integer = &H0000FF00     ' the family, e.g. XX.30xx
Public Const TYP_TYPEMASK                As Integer = &H000000FF     ' the type, e.g. XX.xx12
Public Const TYP_SPEEDMASK               As Integer = &H000000F0     ' the speed grade, e.g. XX.xx1x
Public Const TYP_CHMASK                  As Integer = &H0000000F     ' the channel/modules, e.g. XX.xxx2

Public Const TYP_MISERIES                As Integer = &H00000000
Public Const TYP_MCSERIES                As Integer = &H00010000
Public Const TYP_MXSERIES                As Integer = &H00020000
Public Const TYP_M2ISERIES               As Integer = &H00030000



' ----- MI.20xx, MC.20xx, MX.20xx -----
Public Const TYP_MI2020                  As Integer = &H00002020
Public Const TYP_MI2021                  As Integer = &H00002021
Public Const TYP_MI2025                  As Integer = &H00002025
Public Const TYP_MI2030                  As Integer = &H00002030
Public Const TYP_MI2031                  As Integer = &H00002031

Public Const TYP_M2I2020                 As Integer = &H00032020
Public Const TYP_M2I2021                 As Integer = &H00032021
Public Const TYP_M2I2025                 As Integer = &H00032025
Public Const TYP_M2I2030                 As Integer = &H00032030
Public Const TYP_M2I2031                 As Integer = &H00032031

Public Const TYP_MC2020                  As Integer = &H00012020
Public Const TYP_MC2021                  As Integer = &H00012021
Public Const TYP_MC2025                  As Integer = &H00012025
Public Const TYP_MC2030                  As Integer = &H00012030
Public Const TYP_MC2031                  As Integer = &H00012031

Public Const TYP_MX2020                  As Integer = &H00022020
Public Const TYP_MX2025                  As Integer = &H00022025
Public Const TYP_MX2030                  As Integer = &H00022030



' ----- MI.30xx, MC.30xx, MX.30xx -----
Public Const TYP_MI3010                  As Integer = &H00003010
Public Const TYP_MI3011                  As Integer = &H00003011
Public Const TYP_MI3012                  As Integer = &H00003012
Public Const TYP_MI3013                  As Integer = &H00003013
Public Const TYP_MI3014                  As Integer = &H00003014
Public Const TYP_MI3015                  As Integer = &H00003015
Public Const TYP_MI3016                  As Integer = &H00003016
Public Const TYP_MI3020                  As Integer = &H00003020
Public Const TYP_MI3021                  As Integer = &H00003021
Public Const TYP_MI3022                  As Integer = &H00003022
Public Const TYP_MI3023                  As Integer = &H00003023
Public Const TYP_MI3024                  As Integer = &H00003024
Public Const TYP_MI3025                  As Integer = &H00003025
Public Const TYP_MI3026                  As Integer = &H00003026
Public Const TYP_MI3027                  As Integer = &H00003027
Public Const TYP_MI3031                  As Integer = &H00003031
Public Const TYP_MI3033                  As Integer = &H00003033

Public Const TYP_M2I3010                 As Integer = &H00033010
Public Const TYP_M2I3011                 As Integer = &H00033011
Public Const TYP_M2I3012                 As Integer = &H00033012
Public Const TYP_M2I3013                 As Integer = &H00033013
Public Const TYP_M2I3014                 As Integer = &H00033014
Public Const TYP_M2I3015                 As Integer = &H00033015
Public Const TYP_M2I3016                 As Integer = &H00033016
Public Const TYP_M2I3020                 As Integer = &H00033020
Public Const TYP_M2I3021                 As Integer = &H00033021
Public Const TYP_M2I3022                 As Integer = &H00033022
Public Const TYP_M2I3023                 As Integer = &H00033023
Public Const TYP_M2I3024                 As Integer = &H00033024
Public Const TYP_M2I3025                 As Integer = &H00033025
Public Const TYP_M2I3026                 As Integer = &H00033026
Public Const TYP_M2I3027                 As Integer = &H00033027
Public Const TYP_M2I3031                 As Integer = &H00033031
Public Const TYP_M2I3033                 As Integer = &H00033033

Public Const TYP_MC3010                  As Integer = &H00013010
Public Const TYP_MC3011                  As Integer = &H00013011
Public Const TYP_MC3012                  As Integer = &H00013012
Public Const TYP_MC3013                  As Integer = &H00013013
Public Const TYP_MC3014                  As Integer = &H00013014
Public Const TYP_MC3015                  As Integer = &H00013015
Public Const TYP_MC3016                  As Integer = &H00013016
Public Const TYP_MC3020                  As Integer = &H00013020
Public Const TYP_MC3021                  As Integer = &H00013021
Public Const TYP_MC3022                  As Integer = &H00013022
Public Const TYP_MC3023                  As Integer = &H00013023
Public Const TYP_MC3024                  As Integer = &H00013024
Public Const TYP_MC3025                  As Integer = &H00013025
Public Const TYP_MC3026                  As Integer = &H00013026
Public Const TYP_MC3027                  As Integer = &H00013027
Public Const TYP_MC3031                  As Integer = &H00013031
Public Const TYP_MC3033                  As Integer = &H00013033

Public Const TYP_MX3010                  As Integer = &H00023010
Public Const TYP_MX3011                  As Integer = &H00023011
Public Const TYP_MX3012                  As Integer = &H00023012
Public Const TYP_MX3020                  As Integer = &H00023020
Public Const TYP_MX3021                  As Integer = &H00023021
Public Const TYP_MX3022                  As Integer = &H00023022
Public Const TYP_MX3031                  As Integer = &H00023031



' ----- MI.31xx, MC.31xx, MX.31xx -----
Public Const TYP_MI3110                  As Integer = &H00003110
Public Const TYP_MI3111                  As Integer = &H00003111
Public Const TYP_MI3112                  As Integer = &H00003112
Public Const TYP_MI3120                  As Integer = &H00003120
Public Const TYP_MI3121                  As Integer = &H00003121
Public Const TYP_MI3122                  As Integer = &H00003122
Public Const TYP_MI3130                  As Integer = &H00003130
Public Const TYP_MI3131                  As Integer = &H00003131
Public Const TYP_MI3132                  As Integer = &H00003132
Public Const TYP_MI3140                  As Integer = &H00003140

Public Const TYP_M2I3110                 As Integer = &H00033110
Public Const TYP_M2I3111                 As Integer = &H00033111
Public Const TYP_M2I3112                 As Integer = &H00033112
Public Const TYP_M2I3120                 As Integer = &H00033120
Public Const TYP_M2I3121                 As Integer = &H00033121
Public Const TYP_M2I3122                 As Integer = &H00033122
Public Const TYP_M2I3130                 As Integer = &H00033130
Public Const TYP_M2I3131                 As Integer = &H00033131
Public Const TYP_M2I3132                 As Integer = &H00033132

Public Const TYP_MC3110                  As Integer = &H00013110
Public Const TYP_MC3111                  As Integer = &H00013111
Public Const TYP_MC3112                  As Integer = &H00013112
Public Const TYP_MC3120                  As Integer = &H00013120
Public Const TYP_MC3121                  As Integer = &H00013121
Public Const TYP_MC3122                  As Integer = &H00013122
Public Const TYP_MC3130                  As Integer = &H00013130
Public Const TYP_MC3131                  As Integer = &H00013131
Public Const TYP_MC3132                  As Integer = &H00013132

Public Const TYP_MX3110                  As Integer = &H00023110
Public Const TYP_MX3111                  As Integer = &H00023111
Public Const TYP_MX3120                  As Integer = &H00023120
Public Const TYP_MX3121                  As Integer = &H00023121
Public Const TYP_MX3130                  As Integer = &H00023130
Public Const TYP_MX3131                  As Integer = &H00023131



' ----- MI.40xx, MC.40xx, MX.40xx -----
Public Const TYP_MI4020                  As Integer = &H00004020
Public Const TYP_MI4021                  As Integer = &H00004021
Public Const TYP_MI4022                  As Integer = &H00004022
Public Const TYP_MI4030                  As Integer = &H00004030
Public Const TYP_MI4031                  As Integer = &H00004031
Public Const TYP_MI4032                  As Integer = &H00004032

Public Const TYP_M2I4020                 As Integer = &H00034020
Public Const TYP_M2I4021                 As Integer = &H00034021
Public Const TYP_M2I4022                 As Integer = &H00034022
Public Const TYP_M2I4030                 As Integer = &H00034030
Public Const TYP_M2I4031                 As Integer = &H00034031
Public Const TYP_M2I4032                 As Integer = &H00034032

Public Const TYP_MC4020                  As Integer = &H00014020
Public Const TYP_MC4021                  As Integer = &H00014021
Public Const TYP_MC4022                  As Integer = &H00014022
Public Const TYP_MC4030                  As Integer = &H00014030
Public Const TYP_MC4031                  As Integer = &H00014031
Public Const TYP_MC4032                  As Integer = &H00014032

Public Const TYP_MX4020                  As Integer = &H00024020
Public Const TYP_MX4021                  As Integer = &H00024021
Public Const TYP_MX4030                  As Integer = &H00024030
Public Const TYP_MX4031                  As Integer = &H00024031



' ----- MI.45xx, MC.45xx, MX.45xx -----
Public Const TYP_MI4520                  As Integer = &H00004520
Public Const TYP_MI4521                  As Integer = &H00004521
Public Const TYP_MI4530                  As Integer = &H00004530
Public Const TYP_MI4531                  As Integer = &H00004531
Public Const TYP_MI4540                  As Integer = &H00004540
Public Const TYP_MI4541                  As Integer = &H00004541

Public Const TYP_M2I4520                 As Integer = &H00034520
Public Const TYP_M2I4521                 As Integer = &H00034521
Public Const TYP_M2I4530                 As Integer = &H00034530
Public Const TYP_M2I4531                 As Integer = &H00034531
Public Const TYP_M2I4540                 As Integer = &H00034540
Public Const TYP_M2I4541                 As Integer = &H00034541

Public Const TYP_MC4520                  As Integer = &H00014520
Public Const TYP_MC4521                  As Integer = &H00014521
Public Const TYP_MC4530                  As Integer = &H00014530
Public Const TYP_MC4531                  As Integer = &H00014531
Public Const TYP_MC4540                  As Integer = &H00014540
Public Const TYP_MC4541                  As Integer = &H00014541

Public Const TYP_MX4520                  As Integer = &H00024520
Public Const TYP_MX4530                  As Integer = &H00024530
Public Const TYP_MX4540                  As Integer = &H00024540



' ----- MI.46xx, MC.46xx, MX.46xx -----
Public Const TYP_MI4620                  As Integer = &H00004620
Public Const TYP_MI4621                  As Integer = &H00004621
Public Const TYP_MI4622                  As Integer = &H00004622
Public Const TYP_MI4630                  As Integer = &H00004630
Public Const TYP_MI4631                  As Integer = &H00004631
Public Const TYP_MI4632                  As Integer = &H00004632
Public Const TYP_MI4640                  As Integer = &H00004640
Public Const TYP_MI4641                  As Integer = &H00004641
Public Const TYP_MI4642                  As Integer = &H00004642
Public Const TYP_MI4650                  As Integer = &H00004650
Public Const TYP_MI4651                  As Integer = &H00004651
Public Const TYP_MI4652                  As Integer = &H00004652

Public Const TYP_M2I4620                 As Integer = &H00034620
Public Const TYP_M2I4621                 As Integer = &H00034621
Public Const TYP_M2I4622                 As Integer = &H00034622
Public Const TYP_M2I4630                 As Integer = &H00034630
Public Const TYP_M2I4631                 As Integer = &H00034631
Public Const TYP_M2I4632                 As Integer = &H00034632
Public Const TYP_M2I4640                 As Integer = &H00034640
Public Const TYP_M2I4641                 As Integer = &H00034641
Public Const TYP_M2I4642                 As Integer = &H00034642
Public Const TYP_M2I4650                 As Integer = &H00034650
Public Const TYP_M2I4651                 As Integer = &H00034651
Public Const TYP_M2I4652                 As Integer = &H00034652

Public Const TYP_MC4620                  As Integer = &H00014620
Public Const TYP_MC4621                  As Integer = &H00014621
Public Const TYP_MC4622                  As Integer = &H00014622
Public Const TYP_MC4630                  As Integer = &H00014630
Public Const TYP_MC4631                  As Integer = &H00014631
Public Const TYP_MC4632                  As Integer = &H00014632
Public Const TYP_MC4640                  As Integer = &H00014640
Public Const TYP_MC4641                  As Integer = &H00014641
Public Const TYP_MC4642                  As Integer = &H00014642
Public Const TYP_MC4650                  As Integer = &H00014650
Public Const TYP_MC4651                  As Integer = &H00014651
Public Const TYP_MC4652                  As Integer = &H00014652

Public Const TYP_MX4620                  As Integer = &H00024620
Public Const TYP_MX4621                  As Integer = &H00024621
Public Const TYP_MX4630                  As Integer = &H00024630
Public Const TYP_MX4631                  As Integer = &H00024631
Public Const TYP_MX4640                  As Integer = &H00024640
Public Const TYP_MX4641                  As Integer = &H00024641
Public Const TYP_MX4650                  As Integer = &H00024650
Public Const TYP_MX4651                  As Integer = &H00024651



' ----- MI.47xx, MC.47xx, MX.47xx -----
Public Const TYP_MI4710                  As Integer = &H00004710
Public Const TYP_MI4711                  As Integer = &H00004711
Public Const TYP_MI4712                  As Integer = &H00004712
Public Const TYP_MI4720                  As Integer = &H00004720
Public Const TYP_MI4721                  As Integer = &H00004721
Public Const TYP_MI4722                  As Integer = &H00004722

Public Const TYP_M2I4710                 As Integer = &H00034710
Public Const TYP_M2I4711                 As Integer = &H00034711
Public Const TYP_M2I4712                 As Integer = &H00034712
Public Const TYP_M2I4720                 As Integer = &H00034720
Public Const TYP_M2I4721                 As Integer = &H00034721
Public Const TYP_M2I4722                 As Integer = &H00034722

Public Const TYP_MC4710                  As Integer = &H00014710
Public Const TYP_MC4711                  As Integer = &H00014711
Public Const TYP_MC4712                  As Integer = &H00014712
Public Const TYP_MC4720                  As Integer = &H00014720
Public Const TYP_MC4721                  As Integer = &H00014721
Public Const TYP_MC4722                  As Integer = &H00014722

Public Const TYP_MX4710                  As Integer = &H00024710
Public Const TYP_MX4711                  As Integer = &H00024711
Public Const TYP_MX4720                  As Integer = &H00024720
Public Const TYP_MX4721                  As Integer = &H00024721



' ----- MI.60xx, MC.60xx, MX.60xx -----
Public Const TYP_MI6011                  As Integer = &H00006011
Public Const TYP_MI6012                  As Integer = &H00006012
Public Const TYP_MI6021                  As Integer = &H00006021
Public Const TYP_MI6022                  As Integer = &H00006022
Public Const TYP_MI6030                  As Integer = &H00006030
Public Const TYP_MI6031                  As Integer = &H00006031
Public Const TYP_MI6033                  As Integer = &H00006033
Public Const TYP_MI6034                  As Integer = &H00006034

Public Const TYP_M2I6011                 As Integer = &H00036011
Public Const TYP_M2I6012                 As Integer = &H00036012
Public Const TYP_M2I6021                 As Integer = &H00036021
Public Const TYP_M2I6022                 As Integer = &H00036022
Public Const TYP_M2I6030                 As Integer = &H00036030
Public Const TYP_M2I6031                 As Integer = &H00036031
Public Const TYP_M2I6033                 As Integer = &H00036033
Public Const TYP_M2I6034                 As Integer = &H00036034

Public Const TYP_MC6011                  As Integer = &H00016011
Public Const TYP_MC6012                  As Integer = &H00016012
Public Const TYP_MC6021                  As Integer = &H00016021
Public Const TYP_MC6022                  As Integer = &H00016022
Public Const TYP_MC6030                  As Integer = &H00016030
Public Const TYP_MC6031                  As Integer = &H00016031
Public Const TYP_MC6033                  As Integer = &H00016033
Public Const TYP_MC6034                  As Integer = &H00016034

Public Const TYP_MX6011                  As Integer = &H00026011
Public Const TYP_MX6021                  As Integer = &H00026021
Public Const TYP_MX6030                  As Integer = &H00026030
Public Const TYP_MX6033                  As Integer = &H00026033



' ----- MI.61xx, MC.61xx, MX.61xx -----
Public Const TYP_MI6110                  As Integer = &H00006110
Public Const TYP_MI6111                  As Integer = &H00006111

Public Const TYP_M2I6110                 As Integer = &H00036110
Public Const TYP_M2I6111                 As Integer = &H00036111

Public Const TYP_MC6110                  As Integer = &H00016110
Public Const TYP_MC6111                  As Integer = &H00016111

Public Const TYP_MX6110                  As Integer = &H00026110



' ----- MI.70xx, MC.70xx, MX.70xx -----
Public Const TYP_MI7005                  As Integer = &H00007005
Public Const TYP_MI7010                  As Integer = &H00007010
Public Const TYP_MI7011                  As Integer = &H00007011
Public Const TYP_MI7020                  As Integer = &H00007020
Public Const TYP_MI7021                  As Integer = &H00007021

Public Const TYP_M2I7005                 As Integer = &H00037005
Public Const TYP_M2I7010                 As Integer = &H00037010
Public Const TYP_M2I7011                 As Integer = &H00037011
Public Const TYP_M2I7020                 As Integer = &H00037020
Public Const TYP_M2I7021                 As Integer = &H00037021

Public Const TYP_MC7005                  As Integer = &H00017005
Public Const TYP_MC7010                  As Integer = &H00017010
Public Const TYP_MC7011                  As Integer = &H00017011
Public Const TYP_MC7020                  As Integer = &H00017020
Public Const TYP_MC7021                  As Integer = &H00017021

Public Const TYP_MX7005                  As Integer = &H00027005
Public Const TYP_MX7010                  As Integer = &H00027010
Public Const TYP_MX7011                  As Integer = &H00027011



' ----- MI.72xx, MC.72xx, MX.72xx -----
Public Const TYP_MI7210                  As Integer = &H00007210
Public Const TYP_MI7211                  As Integer = &H00007211
Public Const TYP_MI7220                  As Integer = &H00007220
Public Const TYP_MI7221                  As Integer = &H00007221

Public Const TYP_M2I7210                 As Integer = &H00037210
Public Const TYP_M2I7211                 As Integer = &H00037211
Public Const TYP_M2I7220                 As Integer = &H00037220
Public Const TYP_M2I7221                 As Integer = &H00037221

Public Const TYP_MC7210                  As Integer = &H00017210
Public Const TYP_MC7211                  As Integer = &H00017211
Public Const TYP_MC7220                  As Integer = &H00017220
Public Const TYP_MC7221                  As Integer = &H00017221

Public Const TYP_MX7210                  As Integer = &H00027210
Public Const TYP_MX7220                  As Integer = &H00027220




' ***********************************************************************
' software registers
' ***********************************************************************


' ***** PCI Features Bits (MI/MC/MX and prior cards) *********
Public Const PCIBIT_MULTI                As Integer = &H00000001
Public Const PCIBIT_DIGITAL              As Integer = &H00000002
Public Const PCIBIT_CH0DIGI              As Integer = &H00000004
Public Const PCIBIT_EXTSAM               As Integer = &H00000008
Public Const PCIBIT_3CHANNEL             As Integer = &H00000010
Public Const PCIBIT_GATE                 As Integer = &H00000020
Public Const PCIBIT_SLAVE                As Integer = &H00000040
Public Const PCIBIT_MASTER               As Integer = &H00000080
Public Const PCIBIT_DOUBLEMEM            As Integer = &H00000100
Public Const PCIBIT_SYNC                 As Integer = &H00000200
Public Const PCIBIT_TIMESTAMP            As Integer = &H00000400
Public Const PCIBIT_STARHUB              As Integer = &H00000800
Public Const PCIBIT_CA                   As Integer = &H00001000
Public Const PCIBIT_XIO                  As Integer = &H00002000
Public Const PCIBIT_AMPLIFIER			As Integer = &H00004000
Public Const PCIBIT_ELISA				As Integer = &H10000000


' ***** PCI features starting with M2i card series *****
Public Const SPCM_FEAT_MULTI             As Integer = &H00000001      ' multiple recording
Public Const SPCM_FEAT_GATE              As Integer = &H00000002      ' gated sampling
Public Const SPCM_FEAT_DIGITAL           As Integer = &H00000004      ' additional synchronous digital inputs or outputs
Public Const SPCM_FEAT_TIMESTAMP         As Integer = &H00000008      ' timestamp
Public Const SPCM_FEAT_STARHUB5          As Integer = &H00000020      ' starhub for 5 cards installed
Public Const SPCM_FEAT_STARHUB16         As Integer = &H00000040      ' starhub for 16 cards installed
Public Const SPCM_FEAT_ABA               As Integer = &H00000080      ' ABA mode installed
Public Const SPCM_FEAT_BASEXIO           As Integer = &H00000100      ' extra I/O on base card installed



' ***** Error Request *************
Public Const ERRORTEXTLEN                As Integer = 200
Public Const SPC_LASTERRORTEXT           As Integer = 999996
Public Const SPC_LASTERRORVALUE          As Integer = 999997
Public Const SPC_LASTERRORREG            As Integer = 999998
Public Const SPC_LASTERRORCODE           As Integer = 999999     ' Reading this reset the internal error-memory.



' ***** Register and Command Structure
Public Const SPC_COMMAND                 As Integer = 0
Public Const     SPC_RESET               As Integer = 0
Public Const		SPC_SOFTRESET			As Integer = 1
Public Const     SPC_WRITESETUP          As Integer = 2
Public Const     SPC_START               As Integer = 10
Public Const     SPC_STARTANDWAIT        As Integer = 11
Public Const     SPC_FIFOSTART           As Integer = 12
Public Const     SPC_FIFOWAIT            As Integer = 13
Public Const     SPC_FORCETRIGGER        As Integer = 16
Public Const     SPC_STOP                As Integer = 20
Public Const     SPC_FLUSHFIFOBUFFER     As Integer = 21
Public Const     SPC_POWERDOWN           As Integer = 30
Public Const     SPC_SYNCMASTER          As Integer = 100
Public Const     SPC_SYNCTRIGGERMASTER   As Integer = 101
Public Const     SPC_SYNCMASTERFIFO      As Integer = 102
Public Const     SPC_SYNCSLAVE           As Integer = 110
Public Const     SPC_SYNCTRIGGERSLAVE    As Integer = 111
Public Const     SPC_SYNCSLAVEFIFO       As Integer = 112
Public Const     SPC_NOSYNC              As Integer = 120
Public Const     SPC_SYNCSTART           As Integer = 130
Public Const     SPC_SYNCCALCMASTER      As Integer = 140
Public Const     SPC_SYNCCALCMASTERFIFO  As Integer = 141
Public Const     SPC_RELAISON            As Integer = 200
Public Const     SPC_RELAISOFF           As Integer = 210
Public Const     SPC_ADJUSTSTART         As Integer = 300
Public Const     SPC_FIFO_BUFREADY0      As Integer = 400
Public Const     SPC_FIFO_BUFREADY1      As Integer = 401
Public Const     SPC_FIFO_BUFREADY2      As Integer = 402
Public Const     SPC_FIFO_BUFREADY3      As Integer = 403
Public Const     SPC_FIFO_BUFREADY4      As Integer = 404
Public Const     SPC_FIFO_BUFREADY5      As Integer = 405
Public Const     SPC_FIFO_BUFREADY6      As Integer = 406
Public Const     SPC_FIFO_BUFREADY7      As Integer = 407
Public Const     SPC_FIFO_BUFREADY8      As Integer = 408
Public Const     SPC_FIFO_BUFREADY9      As Integer = 409
Public Const     SPC_FIFO_BUFREADY10     As Integer = 410
Public Const     SPC_FIFO_BUFREADY11     As Integer = 411
Public Const     SPC_FIFO_BUFREADY12     As Integer = 412
Public Const     SPC_FIFO_BUFREADY13     As Integer = 413
Public Const     SPC_FIFO_BUFREADY14     As Integer = 414
Public Const     SPC_FIFO_BUFREADY15     As Integer = 415
Public Const     SPC_FIFO_AUTOBUFSTART   As Integer = 500
Public Const     SPC_FIFO_AUTOBUFEND     As Integer = 510

Public Const SPC_STATUS                  As Integer = 10
Public Const     SPC_RUN                 As Integer = 0
Public Const     SPC_TRIGGER             As Integer = 10
Public Const     SPC_READY               As Integer = 20



' commands for M2 cards
Public Const SPC_M2CMD                   As Integer = 100                ' write a command
Public Const     M2CMD_CARD_RESET            As Integer = &H00000001		' hardware reset   
Public Const     M2CMD_CARD_WRITESETUP	    As Integer = &H00000002 	' write setup only
Public Const     M2CMD_CARD_START			As Integer = &H00000004		' strat of card (including writesetup)
Public Const     M2CMD_CARD_ENABLETRIGGER	As Integer = &H00000008		' enable trigger engine
Public Const     M2CMD_CARD_FORCETRIGGER		As Integer = &H00000010		' force trigger
Public Const     M2CMD_CARD_DISABLETRIGGER	As Integer = &H00000020		' disable trigger engine again (multi or gate)
Public Const     M2CMD_CARD_STOP				As Integer = &H00000040		' stop run
Public Const     M2CMD_CARD_FLUSHFIFO		As Integer = &H00000080		' flush fifos to memory

Public Const     M2CMD_ALL_STOP              As Integer = &H01240020     ' stops card and all running transfers

Public Const     M2CMD_CARD_WAITPREFULL      As Integer = &H00001000		' wait until pretrigger is full
Public Const     M2CMD_CARD_WAITTRIGGER		As Integer = &H00002000		' wait for trigger recognition
Public Const     M2CMD_CARD_WAITREADY		As Integer = &H00004000		' wait for card ready

Public Const     M2CMD_DATA_STARTDMA	        As Integer = &H00010000		' start of DMA transfer for data
Public Const     M2CMD_DATA_WAITDMA		    As Integer = &H00020000		' wait for end of data transfer / next block ready
Public Const     M2CMD_DATA_STOPDMA          As Integer = &H00040000     ' abort the data transfer
Public Const     M2CMD_DATA_POLL             As Integer = &H00080000     ' transfer data using single access and polling

Public Const     M2CMD_EXTRA_STARTDMA        As Integer = &H00100000		' start of DMA transfer for extra (ABA + timestamp) data
Public Const     M2CMD_EXTRA_WAITDMA         As Integer = &H00200000		' wait for end of extra (ABA + timestamp) data transfer / next block ready
Public Const     M2CMD_EXTRA_STOPDMA         As Integer = &H00400000     ' abort the extra (ABA + timestamp) data transfer
Public Const     M2CMD_EXTRA_POLL            As Integer = &H00800000     ' transfer data using single access and polling



' status for M2 cards (bitmask)
Public Const SPC_M2STATUS                As Integer = 110                ' read the current status
Public Const     M2STAT_NONE                 As Integer = &H00000000     ' status empty
Public Const     M2STAT_CARD_PRETRIGGER		As Integer = &H00000001		' pretrigger area is full
Public Const     M2STAT_CARD_TRIGGER			As Integer = &H00000002		' trigger recognized
Public Const     M2STAT_CARD_READY			As Integer = &H00000004		' card is ready, run finished

Public Const     M2STAT_DATA_BLOCKREADY		As Integer = &H00000100		' next data block is available
Public Const     M2STAT_DATA_END             As Integer = &H00000200     ' data transfer has ended
Public Const     M2STAT_DATA_OVERRUN         As Integer = &H00000400     ' FIFO overrun (record) or underrun (replay)
Public Const     M2STAT_DATA_ERROR           As Integer = &H00000800     ' internal error

Public Const     M2STAT_EXTRA_BLOCKREADY		As Integer = &H00001000		' next extra data (ABA and timestamp) block is available
Public Const     M2STAT_EXTRA_END            As Integer = &H00002000     ' extra data (ABA and timestamp) transfer has ended
Public Const     M2STAT_EXTRA_OVERRUN        As Integer = &H00004000     ' FIFO overrun
Public Const     M2STAT_EXTRA_ERROR          As Integer = &H00008000     ' internal error

Public Const     M2STAT_INTERNALMASK         As Integer = &Hff000000     ' mask for internal status signals
Public Const     M2STAT_INTERNAL_SYSLOCK     As Integer = &H02000000


' buffer control registers for samples data
Public Const SPC_DATA_AVAIL_USER_LEN     As Integer = 200                ' number of bytes available for user (valid data if READ, free buffer if WRITE)
Public Const SPC_DATA_AVAIL_USER_POS     As Integer = 201                ' the current byte position where the available user data starts
Public Const SPC_DATA_AVAIL_CARD_LEN     As Integer = 202                ' number of bytes available for card (free buffer if READ, filled data if WRITE)

' buffer control registers for extra data (ABA slow data, timestamps)
Public Const SPC_ABA_AVAIL_USER_LEN      As Integer = 210                ' number of bytes available for user (valid data if READ, free buffer if WRITE)
Public Const SPC_ABA_AVAIL_USER_POS      As Integer = 211                ' the current byte position where the available user data starts
Public Const SPC_ABA_AVAIL_CARD_LEN      As Integer = 212                ' number of bytes available for card (free buffer if READ, filled data if WRITE)

Public Const SPC_TS_AVAIL_USER_LEN       As Integer = 220                ' number of bytes available for user (valid data if READ, free buffer if WRITE)
Public Const SPC_TS_AVAIL_USER_POS       As Integer = 221                ' the current byte position where the available user data starts
Public Const SPC_TS_AVAIL_CARD_LEN       As Integer = 222                ' number of bytes available for card (free buffer if READ, filled data if WRITE)


' Installation
Public Const SPC_VERSION                 As Integer = 1000
Public Const SPC_ISAADR                  As Integer = 1010
Public Const SPC_INSTMEM                 As Integer = 1020
Public Const SPC_INSTSAMPLERATE          As Integer = 1030
Public Const SPC_BRDTYP                  As Integer = 1040

' MI/MC/MX type information (internal use)
Public Const SPC_MIINST_MODULES          As Integer = 1100
Public Const SPC_MIINST_CHPERMODULE      As Integer = 1110
Public Const SPC_MIINST_BYTESPERSAMPLE   As Integer = 1120
Public Const SPC_MIINST_BITSPERSAMPLE    As Integer = 1125
Public Const SPC_MIINST_MINADCLOCK       As Integer = 1130
Public Const SPC_MIINST_MAXADCLOCK       As Integer = 1140
Public Const SPC_MIINST_QUARZ            As Integer = 1150
Public Const SPC_MIINST_QUARZ2           As Integer = 1151
Public Const SPC_MIINST_FLAGS            As Integer = 1160
Public Const SPC_MIINST_FIFOSUPPORT      As Integer = 1170
Public Const SPC_MIINST_ISDEMOCARD       As Integer = 1175

' Driver information
Public Const SPC_GETDRVVERSION           As Integer = 1200
Public Const SPC_GETKERNELVERSION        As Integer = 1210
Public Const SPC_GETDRVTYPE              As Integer = 1220
Public Const     DRVTYP_DOS              As Integer = 0
Public Const     DRVTYP_LINUX            As Integer = 1
Public Const     DRVTYP_VXD              As Integer = 2
Public Const     DRVTYP_NTLEGACY         As Integer = 3
Public Const     DRVTYP_WDM              As Integer = 4
Public Const SPC_GETCOMPATIBILITYVERSION As Integer = 1230

' PCI, CompactPCI and PXI Installation Information
Public Const SPC_PCITYP                  As Integer = 2000

' ***** available card function types *****
Public Const SPC_FNCTYPE                 As Integer = 2001
Public Const     SPCM_TYPE_AI            As Integer = &H01
Public Const     SPCM_TYPE_AO            As Integer = &H02
Public Const     SPCM_TYPE_DI            As Integer = &H04
Public Const     SPCM_TYPE_DO            As Integer = &H08
Public Const     SPCM_TYPE_DIO           As Integer = &H10

Public Const SPC_PCIVERSION              As Integer = 2010
Public Const SPC_PCIEXTVERSION           As Integer = 2011
Public Const SPC_PCIMODULEVERSION        As Integer = 2012
Public Const SPC_PCIDATE                 As Integer = 2020
Public Const SPC_CALIBDATE               As Integer = 2025
Public Const SPC_PCISERIALNR             As Integer = 2030
Public Const SPC_PCISERIALNO             As Integer = 2030
Public Const SPC_PCISAMPLERATE           As Integer = 2100
Public Const SPC_PCIMEMSIZE              As Integer = 2110
Public Const SPC_PCIFEATURES             As Integer = 2120
Public Const SPC_PCIINFOADR              As Integer = 2200
Public Const SPC_PCIINTERRUPT            As Integer = 2300
Public Const SPC_PCIBASEADR0             As Integer = 2400
Public Const SPC_PCIBASEADR1             As Integer = 2401
Public Const SPC_PCIREGION0              As Integer = 2410
Public Const SPC_PCIREGION1              As Integer = 2411
Public Const SPC_READTRGLVLCOUNT         As Integer = 2500
Public Const SPC_READIRCOUNT             As Integer = 3000
Public Const SPC_READUNIPOLAR0           As Integer = 3010
Public Const SPC_READUNIPOLAR1           As Integer = 3020
Public Const SPC_READUNIPOLAR2           As Integer = 3030
Public Const SPC_READUNIPOLAR3           As Integer = 3040
Public Const SPC_READMAXOFFSET           As Integer = 3100

Public Const SPC_READAIFEATURES          As Integer = 3101
Public Const     SPCM_AI_TERM            As Integer = &H00000001  ' input termination available
Public Const     SPCM_AI_SE              As Integer = &H00000002  ' single-ended mode available
Public Const     SPCM_AI_DIFF            As Integer = &H00000004  ' differential mode available
Public Const     SPCM_AI_OFFSPERCENT     As Integer = &H00000008  ' offset programming is done in percent of input range
Public Const     SPCM_AI_OFFSMV          As Integer = &H00000010  ' offset programming is done in mV absolut
Public Const     SPCM_AI_AUTOCALOFFS     As Integer = &H00001000  ' automatic offset calibration in hardware
Public Const     SPCM_AI_AUTOCALGAIN     As Integer = &H00002000  ' automatic gain calibration in hardware
Public Const     SPCM_AI_AUTOCALOFFSNOIN As Integer = &H00004000  ' automatic offset calibration with open inputs

Public Const SPC_READAOFEATURES          As Integer = 3102
Public Const     SPCM_AO_SE              As Integer = &H00000002  ' single-ended mode available
Public Const     SPCM_AO_DIFF            As Integer = &H00000004  ' differential mode available
Public Const     SPCM_AO_PROGFILTER      As Integer = &H00000008  ' programmable filters available
Public Const     SPCM_AO_PROGOFFSET      As Integer = &H00000010  ' programmable offset available
Public Const     SPCM_AO_PROGGAIN        As Integer = &H00000020  ' programmable gain available
Public Const     SPCM_AO_PROGSTOPLEVEL   As Integer = &H00000040  ' programmable stop level available

Public Const SPC_READDIFEATURES          As Integer = 3103
Public Const     SPCM_DI_TERM            As Integer = &H00000001  ' input termination available
Public Const     SPCM_DI_SE              As Integer = &H00000002  ' single-ended mode available
Public Const     SPCM_DI_DIFF            As Integer = &H00000004  ' differential mode available

Public Const SPC_READDOFEATURES          As Integer = 3104
Public Const     SPCM_DO_SE              As Integer = &H00000002  ' single-ended mode available
Public Const     SPCM_DO_DIFF            As Integer = &H00000004  ' differential mode available
Public Const     SPCM_DO_PROGSTOPLEVEL   As Integer = &H00000008  ' programmable stop level available
Public Const     SPCM_DO_PROGOUTLEVELS   As Integer = &H00000010  ' programmable output levels (low + high) available

Public Const SPC_READCHGROUPING          As Integer = 3110

Public Const SPC_READRANGECH0_0          As Integer = 3200
Public Const SPC_READRANGECH0_1          As Integer = 3201
Public Const SPC_READRANGECH0_2          As Integer = 3202
Public Const SPC_READRANGECH0_3          As Integer = 3203
Public Const SPC_READRANGECH0_4          As Integer = 3204
Public Const SPC_READRANGECH0_5          As Integer = 3205
Public Const SPC_READRANGECH0_6          As Integer = 3206
Public Const SPC_READRANGECH0_7          As Integer = 3207
Public Const SPC_READRANGECH0_8          As Integer = 3208
Public Const SPC_READRANGECH0_9          As Integer = 3209
Public Const SPC_READRANGECH1_0          As Integer = 3300
Public Const SPC_READRANGECH1_1          As Integer = 3301
Public Const SPC_READRANGECH1_2          As Integer = 3302
Public Const SPC_READRANGECH1_3          As Integer = 3303
Public Const SPC_READRANGECH1_4          As Integer = 3304
Public Const SPC_READRANGECH1_5          As Integer = 3305
Public Const SPC_READRANGECH1_6          As Integer = 3306
Public Const SPC_READRANGECH1_7          As Integer = 3307
Public Const SPC_READRANGECH1_8          As Integer = 3308
Public Const SPC_READRANGECH1_9          As Integer = 3309
Public Const SPC_READRANGECH2_0          As Integer = 3400
Public Const SPC_READRANGECH2_1          As Integer = 3401
Public Const SPC_READRANGECH2_2          As Integer = 3402
Public Const SPC_READRANGECH2_3          As Integer = 3403
Public Const SPC_READRANGECH3_0          As Integer = 3500
Public Const SPC_READRANGECH3_1          As Integer = 3501
Public Const SPC_READRANGECH3_2          As Integer = 3502
Public Const SPC_READRANGECH3_3          As Integer = 3503

Public Const SPC_READRANGEMIN0           As Integer = 4000
Public Const SPC_READRANGEMIN99          As Integer = 4099
Public Const SPC_READRANGEMAX0           As Integer = 4100
Public Const SPC_READRANGEMAX99          As Integer = 4199
Public Const SPC_READOFFSMIN0            As Integer = 4200
Public Const SPC_READOFFSMIN99           As Integer = 4299
Public Const SPC_READOFFSMAX0            As Integer = 4300
Public Const SPC_READOFFSMAX99           As Integer = 4399
Public Const SPC_PCICOUNTER              As Integer = 9000
Public Const SPC_BUFFERPOS               As Integer = 9010


Public Const SPC_CARDMODE                As Integer = 9500       ' card modes as listed below
Public Const SPC_AVAILCARDMODES          As Integer = 9501       ' list with available card modes

' card modes
Public Const     SPC_REC_STD_SINGLE          As Integer = &H00000001  ' singleshot recording to memory
Public Const     SPC_REC_STD_MULTI           As Integer = &H00000002  ' multiple records to memory on each trigger event
Public Const     SPC_REC_STD_GATE            As Integer = &H00000004  ' gated recording to memory on gate signal
Public Const     SPC_REC_STD_ABA             As Integer = &H00000008  ' ABA: A slowly to extra FIFO, B to memory on each trigger event 

Public Const     SPC_REC_FIFO_SINGLE         As Integer = &H00000010  ' singleshot to FIFO on trigger event
Public Const     SPC_REC_FIFO_MULTI          As Integer = &H00000020  ' multiple records to FIFO on each trigger event
Public Const     SPC_REC_FIFO_GATE           As Integer = &H00000040  ' gated sampling to FIFO on gate signal
Public Const     SPC_REC_FIFO_ABA            As Integer = &H00000080  ' ABA: A slowly to extra FIFO, B to FIFO on each trigger event

Public Const     SPC_REP_STD_SINGLE          As Integer = &H00000100  ' single replay from memory on trigger event 
Public Const     SPC_REP_STD_MULTI           As Integer = &H00000200  ' multiple replay from memory on each trigger event
Public Const     SPC_REP_STD_GATE            As Integer = &H00000400  ' gated replay from memory on gate signal

Public Const     SPC_REP_FIFO_SINGLE         As Integer = &H00000800  ' single replay from FIFO on trigger event
Public Const     SPC_REP_FIFO_MULTI          As Integer = &H00001000  ' multiple replay from FIFO on each trigger event
Public Const     SPC_REP_FIFO_GATE           As Integer = &H00002000  ' gated replay from FIFO on gate signal

Public Const     SPC_REP_STD_CONTINUOUS      As Integer = &H00004000  ' continuous replay started by one trigger event




' Memory
Public Const SPC_MEMSIZE                 As Integer = 10000
Public Const SPC_SEGMENTSIZE             As Integer = 10010
Public Const SPC_LOOPS                   As Integer = 10020
Public Const SPC_PRETRIGGER              As Integer = 10030
Public Const SPC_ABADIVIDER              As Integer = 10040
Public Const SPC_POSTTRIGGER             As Integer = 10100
Public Const SPC_STARTOFFSET             As Integer = 10200





' Channels
Public Const SPC_CHENABLE                As Integer = 11000
Public Const SPC_CHCOUNT                 As Integer = 11001


' ----- channel enable flags for A/D and D/A boards (MI/MC/MX series) -----
'       and all cards on M2i series
Public Const     CHANNEL0                As Integer = &H00000001
Public Const     CHANNEL1                As Integer = &H00000002
Public Const     CHANNEL2                As Integer = &H00000004
Public Const     CHANNEL3                As Integer = &H00000008
Public Const     CHANNEL4                As Integer = &H00000010
Public Const     CHANNEL5                As Integer = &H00000020
Public Const     CHANNEL6                As Integer = &H00000040
Public Const     CHANNEL7                As Integer = &H00000080
Public Const     CHANNEL8                As Integer = &H00000100
Public Const     CHANNEL9                As Integer = &H00000200
Public Const     CHANNEL10               As Integer = &H00000400
Public Const     CHANNEL11               As Integer = &H00000800
Public Const     CHANNEL12               As Integer = &H00001000
Public Const     CHANNEL13               As Integer = &H00002000
Public Const     CHANNEL14               As Integer = &H00004000
Public Const     CHANNEL15               As Integer = &H00008000
Public Const     CHANNEL16               As Integer = &H00010000
Public Const     CHANNEL17               As Integer = &H00020000
Public Const     CHANNEL18               As Integer = &H00040000
Public Const     CHANNEL19               As Integer = &H00080000
Public Const     CHANNEL20               As Integer = &H00100000
Public Const     CHANNEL21               As Integer = &H00200000
Public Const     CHANNEL22               As Integer = &H00400000
Public Const     CHANNEL23               As Integer = &H00800000
Public Const     CHANNEL24               As Integer = &H01000000
Public Const     CHANNEL25               As Integer = &H02000000
Public Const     CHANNEL26               As Integer = &H04000000
Public Const     CHANNEL27               As Integer = &H08000000
Public Const     CHANNEL28               As Integer = &H10000000
Public Const     CHANNEL29               As Integer = &H20000000
Public Const     CHANNEL30               As Integer = &H40000000
Public Const     CHANNEL31               As Integer = &H80000000
' CHANNEL32 up to CHANNEL63 are placed in the upper 32 bit of a 64 bit word (M2i only)


' ----- old digital i/o settings for 16 bit implementation (MI/MC/MX series)  -----
Public Const     CH0_8BITMODE            As Integer = 65536  ' for MI.70xx only
Public Const     CH0_16BIT               As Integer = 1
Public Const     CH0_32BIT               As Integer = 3
Public Const     CH1_16BIT               As Integer = 4
Public Const     CH1_32BIT               As Integer = 12

' ----- new digital i/o settings for 8 bit implementation (MI/MC/MX series) -----
Public Const     MOD0_8BIT               As Integer = 1
Public Const     MOD0_16BIT              As Integer = 3
Public Const     MOD0_32BIT              As Integer = 15
Public Const     MOD1_8BIT               As Integer = 16
Public Const     MOD1_16BIT              As Integer = 48
Public Const     MOD1_32BIT              As Integer = 240

Public Const SPC_CHROUTE0                As Integer = 11010
Public Const SPC_CHROUTE1                As Integer = 11020

Public Const SPC_BITENABLE               As Integer = 11030



' ----- Clock Settings -----
Public Const SPC_SAMPLERATE              As Integer = 20000
Public Const SPC_SAMPLERATE2             As Integer = 20010
Public Const SPC_SR2                     As Integer = 20020
Public Const SPC_PLL_ENABLE              As Integer = 20030
Public Const SPC_CLOCKDIV                As Integer = 20040
Public Const SPC_INTCLOCKDIV             As Integer = 20041
Public Const SPC_PLL_R                   As Integer = 20060
Public Const SPC_PLL_F                   As Integer = 20061
Public Const SPC_PLL_S                   As Integer = 20062
Public Const SPC_PLL_DIV                 As Integer = 20063
Public Const SPC_EXTERNALCLOCK           As Integer = 20100
Public Const SPC_EXTERNOUT               As Integer = 20110
Public Const SPC_CLOCKOUT                As Integer = 20110
Public Const SPC_CLOCK50OHM              As Integer = 20120
Public Const SPC_CLOCK110OHM             As Integer = 20120
Public Const SPC_EXTERNRANGE             As Integer = 20130
Public Const     EXRANGE_NOPLL           As Integer = 1
Public Const     EXRANGE_SINGLE          As Integer = 2
Public Const     EXRANGE_BURST_S         As Integer = 4
Public Const     EXRANGE_BURST_M         As Integer = 8
Public Const     EXRANGE_BURST_L         As Integer = 16
Public Const     EXRANGE_BURST_XL        As Integer = 32
Public Const     EXRANGE_LOW             As Integer = 64
Public Const     EXRANGE_HIGH            As Integer = 128
Public Const     EXRANGE_LOW_DPS         As Integer = 256            ' digital phase synchronization
Public Const SPC_REFERENCECLOCK          As Integer = 20140
Public Const     REFCLOCK_PXI            As Integer = -1

' ----- new clock registers starting with M2i cards -----
Public Const SPC_CLOCKMODE               As Integer = 20200      ' clock mode as listed below
Public Const SPC_AVAILCLOCKMODES         As Integer = 20201      ' returns all available clock modes
Public Const     SPC_CM_INTPLL           As Integer = 1              ' use internal PLL
Public Const     SPC_CM_QUARTZ1          As Integer = 2              ' use plain quartz1 (with divider)
Public Const     SPC_CM_QUARTZ2          As Integer = 4              ' use plain quartz2 (with divider)
Public Const     SPC_CM_EXTERNAL         As Integer = 8              ' use external clock directly
Public Const     SPC_CM_EXTDIVIDER       As Integer = 16             ' use external clock with programmed divider
Public Const     SPC_CM_EXTREFCLOCK      As Integer = 32             ' external reference clock fed in (defined with SPC_REFERENCECLOCK)



' ----- In/Out Range -----
Public Const SPC_OFFS0                   As Integer = 30000
Public Const SPC_AMP0                    As Integer = 30010
Public Const SPC_ACDC0                   As Integer = 30020
Public Const SPC_50OHM0                  As Integer = 30030
Public Const SPC_DIFF0                   As Integer = 30040
Public Const SPC_DOUBLEOUT0              As Integer = 30041
Public Const SPC_DIGITAL0                As Integer = 30050
Public Const SPC_110OHM0                 As Integer = 30060
Public Const SPC_110OHM0L                As Integer = 30060
Public Const SPC_INOUT0                  As Integer = 30070
Public Const SPC_FILTER0                 As Integer = 30080
Public Const SPC_BANKSWITCH0             As Integer = 30081

Public Const SPC_OFFS1                   As Integer = 30100
Public Const SPC_AMP1                    As Integer = 30110
Public Const SPC_ACDC1                   As Integer = 30120
Public Const SPC_50OHM1                  As Integer = 30130
Public Const SPC_DIFF1                   As Integer = 30140
Public Const SPC_DOUBLEOUT1              As Integer = 30141
Public Const SPC_DIGITAL1                As Integer = 30150
Public Const SPC_110OHM1                 As Integer = 30160
Public Const SPC_110OHM0H                As Integer = 30160
Public Const SPC_INOUT1                  As Integer = 30170
Public Const SPC_FILTER1                 As Integer = 30180
Public Const SPC_BANKSWITCH1             As Integer = 30181

Public Const SPC_OFFS2                   As Integer = 30200
Public Const SPC_AMP2                    As Integer = 30210
Public Const SPC_ACDC2                   As Integer = 30220
Public Const SPC_50OHM2                  As Integer = 30230
Public Const SPC_DIFF2                   As Integer = 30240
Public Const SPC_DOUBLEOUT2              As Integer = 30241
Public Const SPC_110OHM2                 As Integer = 30260
Public Const SPC_110OHM1L                As Integer = 30260
Public Const SPC_INOUT2                  As Integer = 30270
Public Const SPC_FILTER2                 As Integer = 30280
Public Const SPC_BANKSWITCH2             As Integer = 30281

Public Const SPC_OFFS3                   As Integer = 30300
Public Const SPC_AMP3                    As Integer = 30310
Public Const SPC_ACDC3                   As Integer = 30320
Public Const SPC_50OHM3                  As Integer = 30330
Public Const SPC_DIFF3                   As Integer = 30340
Public Const SPC_DOUBLEOUT3              As Integer = 30341
Public Const SPC_110OHM3                 As Integer = 30360
Public Const SPC_110OHM1H                As Integer = 30360
Public Const SPC_INOUT3                  As Integer = 30370
Public Const SPC_FILTER3                 As Integer = 30380
Public Const SPC_BANKSWITCH3             As Integer = 30381

Public Const SPC_OFFS4                   As Integer = 30400
Public Const SPC_AMP4                    As Integer = 30410
Public Const SPC_ACDC4                   As Integer = 30420
Public Const SPC_50OHM4                  As Integer = 30430
Public Const SPC_DIFF4                   As Integer = 30440

Public Const SPC_OFFS5                   As Integer = 30500
Public Const SPC_AMP5                    As Integer = 30510
Public Const SPC_ACDC5                   As Integer = 30520
Public Const SPC_50OHM5                  As Integer = 30530
Public Const SPC_DIFF5                   As Integer = 30540

Public Const SPC_OFFS6                   As Integer = 30600
Public Const SPC_AMP6                    As Integer = 30610
Public Const SPC_ACDC6                   As Integer = 30620
Public Const SPC_50OHM6                  As Integer = 30630
Public Const SPC_DIFF6                   As Integer = 30640

Public Const SPC_OFFS7                   As Integer = 30700
Public Const SPC_AMP7                    As Integer = 30710
Public Const SPC_ACDC7                   As Integer = 30720
Public Const SPC_50OHM7                  As Integer = 30730
Public Const SPC_DIFF7                   As Integer = 30740

Public Const SPC_OFFS8                   As Integer = 30800
Public Const SPC_AMP8                    As Integer = 30810
Public Const SPC_ACDC8                   As Integer = 30820
Public Const SPC_50OHM8                  As Integer = 30830
Public Const SPC_DIFF8                   As Integer = 30840

Public Const SPC_OFFS9                   As Integer = 30900
Public Const SPC_AMP9                    As Integer = 30910
Public Const SPC_ACDC9                   As Integer = 30920
Public Const SPC_50OHM9                  As Integer = 30930
Public Const SPC_DIFF9                   As Integer = 30940

Public Const SPC_OFFS10                  As Integer = 31000
Public Const SPC_AMP10                   As Integer = 31010
Public Const SPC_ACDC10                  As Integer = 31020
Public Const SPC_50OHM10                 As Integer = 31030
Public Const SPC_DIFF10                  As Integer = 31040

Public Const SPC_OFFS11                  As Integer = 31100
Public Const SPC_AMP11                   As Integer = 31110
Public Const SPC_ACDC11                  As Integer = 31120
Public Const SPC_50OHM11                 As Integer = 31130
Public Const SPC_DIFF11                  As Integer = 31140

Public Const SPC_OFFS12                  As Integer = 31200
Public Const SPC_AMP12                   As Integer = 31210
Public Const SPC_ACDC12                  As Integer = 31220
Public Const SPC_50OHM12                 As Integer = 31230
Public Const SPC_DIFF12                  As Integer = 31240

Public Const SPC_OFFS13                  As Integer = 31300
Public Const SPC_AMP13                   As Integer = 31310
Public Const SPC_ACDC13                  As Integer = 31320
Public Const SPC_50OHM13                 As Integer = 31330
Public Const SPC_DIFF13                  As Integer = 31340

Public Const SPC_OFFS14                  As Integer = 31400
Public Const SPC_AMP14                   As Integer = 31410
Public Const SPC_ACDC14                  As Integer = 31420
Public Const SPC_50OHM14                 As Integer = 31430
Public Const SPC_DIFF14                  As Integer = 31440

Public Const SPC_OFFS15                  As Integer = 31500
Public Const SPC_AMP15                   As Integer = 31510
Public Const SPC_ACDC15                  As Integer = 31520
Public Const SPC_50OHM15                 As Integer = 31530
Public Const SPC_DIFF15                  As Integer = 31540

Public Const SPC_110OHMTRIGGER           As Integer = 30400
Public Const SPC_110OHMCLOCK             As Integer = 30410


Public Const   AMP_BI200                 As Integer = 200
Public Const   AMP_BI500                 As Integer = 500
Public Const   AMP_BI1000                As Integer = 1000
Public Const   AMP_BI2000                As Integer = 2000
Public Const   AMP_BI2500                As Integer = 2500
Public Const   AMP_BI4000                As Integer = 4000
Public Const   AMP_BI5000                As Integer = 5000
Public Const   AMP_BI10000               As Integer = 10000
Public Const   AMP_UNI400                As Integer = 100400
Public Const   AMP_UNI1000               As Integer = 101000
Public Const   AMP_UNI2000               As Integer = 102000


' ----- Trigger Settings -----
Public Const SPC_TRIGGERMODE             As Integer = 40000
Public Const SPC_TRIG_OUTPUT             As Integer = 40100
Public Const SPC_TRIGGEROUT              As Integer = 40100
Public Const SPC_TRIG_TERM               As Integer = 40110
Public Const SPC_TRIGGER50OHM            As Integer = 40110
Public Const SPC_TRIGGER110OHM0          As Integer = 40110
Public Const SPC_TRIGGER110OHM1          As Integer = 40111

Public Const SPC_TRIGGERMODE0            As Integer = 40200
Public Const SPC_TRIGGERMODE1            As Integer = 40201
Public Const SPC_TRIGGERMODE2            As Integer = 40202
Public Const SPC_TRIGGERMODE3            As Integer = 40203
Public Const SPC_TRIGGERMODE4            As Integer = 40204
Public Const SPC_TRIGGERMODE5            As Integer = 40205
Public Const SPC_TRIGGERMODE6            As Integer = 40206
Public Const SPC_TRIGGERMODE7            As Integer = 40207
Public Const SPC_TRIGGERMODE8            As Integer = 40208
Public Const SPC_TRIGGERMODE9            As Integer = 40209
Public Const SPC_TRIGGERMODE10           As Integer = 40210
Public Const SPC_TRIGGERMODE11           As Integer = 40211
Public Const SPC_TRIGGERMODE12           As Integer = 40212
Public Const SPC_TRIGGERMODE13           As Integer = 40213
Public Const SPC_TRIGGERMODE14           As Integer = 40214
Public Const SPC_TRIGGERMODE15           As Integer = 40215

Public Const     TM_SOFTWARE             As Integer = 0
Public Const     TM_NOTRIGGER            As Integer = 10
Public Const     TM_CHXPOS               As Integer = 10000
Public Const     TM_CHXPOS_LP            As Integer = 10001
Public Const     TM_CHXPOS_SP            As Integer = 10002
Public Const     TM_CHXPOS_GS            As Integer = 10003
Public Const     TM_CHXPOS_SS            As Integer = 10004
Public Const     TM_CHXNEG               As Integer = 10010
Public Const     TM_CHXNEG_LP            As Integer = 10011
Public Const     TM_CHXNEG_SP            As Integer = 10012
Public Const     TM_CHXNEG_GS            As Integer = 10013
Public Const     TM_CHXNEG_SS            As Integer = 10014
Public Const     TM_CHXOFF               As Integer = 10020
Public Const     TM_CHXBOTH              As Integer = 10030
Public Const     TM_CHXWINENTER          As Integer = 10040
Public Const     TM_CHXWINENTER_LP       As Integer = 10041
Public Const     TM_CHXWINENTER_SP       As Integer = 10042
Public Const     TM_CHXWINLEAVE          As Integer = 10050
Public Const     TM_CHXWINLEAVE_LP       As Integer = 10051
Public Const     TM_CHXWINLEAVE_SP       As Integer = 10052

Public Const     TM_CH0POS               As Integer = 10000
Public Const     TM_CH0NEG               As Integer = 10010
Public Const     TM_CH0OFF               As Integer = 10020
Public Const     TM_CH0BOTH              As Integer = 10030
Public Const     TM_CH1POS               As Integer = 10100
Public Const     TM_CH1NEG               As Integer = 10110
Public Const     TM_CH1OFF               As Integer = 10120
Public Const     TM_CH1BOTH              As Integer = 10130
Public Const     TM_CH2POS               As Integer = 10200
Public Const     TM_CH2NEG               As Integer = 10210
Public Const     TM_CH2OFF               As Integer = 10220
Public Const     TM_CH2BOTH              As Integer = 10230
Public Const     TM_CH3POS               As Integer = 10300
Public Const     TM_CH3NEG               As Integer = 10310
Public Const     TM_CH3OFF               As Integer = 10320
Public Const     TM_CH3BOTH              As Integer = 10330

Public Const     TM_TTLPOS               As Integer = 20000
Public Const     TM_TTLHIGH_LP           As Integer = 20001
Public Const     TM_TTLHIGH_SP           As Integer = 20002
Public Const     TM_TTLNEG               As Integer = 20010
Public Const     TM_TTLLOW_LP            As Integer = 20011
Public Const     TM_TTLLOW_SP            As Integer = 20012
Public Const     TM_TTL                  As Integer = 20020
Public Const     TM_TTLBOTH              As Integer = 20030
Public Const     TM_TTLBOTH_LP           As Integer = 20031
Public Const     TM_TTLBOTH_SP           As Integer = 20032
Public Const     TM_CHANNEL              As Integer = 20040
Public Const     TM_PATTERN              As Integer = 21000
Public Const     TM_PATTERN_LP           As Integer = 21001
Public Const     TM_PATTERN_SP           As Integer = 21002
Public Const     TM_PATTERNANDEDGE       As Integer = 22000
Public Const     TM_PATTERNANDEDGE_LP    As Integer = 22001
Public Const     TM_PATTERNANDEDGE_SP    As Integer = 22002
Public Const     TM_GATELOW              As Integer = 30000
Public Const     TM_GATEHIGH             As Integer = 30010
Public Const     TM_GATEPATTERN          As Integer = 30020
Public Const     TM_CHOR                 As Integer = 35000
Public Const     TM_CHAND                As Integer = 35010

Public Const SPC_PXITRGOUT               As Integer = 40300
Public Const     PTO_OFF                  As Integer = 0
Public Const     PTO_LINE0                As Integer = 1
Public Const     PTO_LINE1                As Integer = 2
Public Const     PTO_LINE2                As Integer = 3
Public Const     PTO_LINE3                As Integer = 4
Public Const     PTO_LINE4                As Integer = 5
Public Const     PTO_LINE5                As Integer = 6
Public Const     PTO_LINE6                As Integer = 7
Public Const     PTO_LINE7                As Integer = 8
Public Const     PTO_LINESTAR             As Integer = 9
Public Const SPC_PXITRGOUT_AVAILABLE     As Integer = 40301  ' bitmap register


Public Const SPC_PXITRGIN                As Integer = 40310  ' bitmap register
Public Const     PTI_OFF                  As Integer = 0
Public Const     PTI_LINE0                As Integer = 1
Public Const     PTI_LINE1                As Integer = 2
Public Const     PTI_LINE2                As Integer = 4
Public Const     PTI_LINE3                As Integer = 8
Public Const     PTI_LINE4                As Integer = 16
Public Const     PTI_LINE5                As Integer = 32
Public Const     PTI_LINE6                As Integer = 64
Public Const     PTI_LINE7                As Integer = 128
Public Const     PTI_LINESTAR             As Integer = 256
Public Const SPC_PXITRGIN_AVAILABLE      As Integer = 40311  ' bitmap register


' new registers of M2i driver
Public Const SPC_TRIG_AVAILORMASK        As Integer = 40400
Public Const SPC_TRIG_ORMASK             As Integer = 40410
Public Const SPC_TRIG_AVAILANDMASK       As Integer = 40420
Public Const SPC_TRIG_ANDMASK            As Integer = 40430
Public Const     SPC_TMASK_SOFTWARE      As Integer = &H00000001
Public Const     SPC_TMASK_EXT0          As Integer = &H00000002  
Public Const     SPC_TMASK_EXT1          As Integer = &H00000004
Public Const     SPC_TMASK_XIO0          As Integer = &H00000100 
Public Const     SPC_TMASK_XIO1          As Integer = &H00000200
Public Const     SPC_TMASK_XIO2          As Integer = &H00000400
Public Const     SPC_TMASK_XIO3          As Integer = &H00000800
Public Const     SPC_TMASK_XIO4          As Integer = &H00001000
Public Const     SPC_TMASK_XIO5          As Integer = &H00002000
Public Const     SPC_TMASK_XIO6          As Integer = &H00004000
Public Const     SPC_TMASK_XIO7          As Integer = &H00008000
Public Const     SPC_TMASK_PXI0          As Integer = &H00100000  
Public Const     SPC_TMASK_PXI1          As Integer = &H00200000  
Public Const     SPC_TMASK_PXI2          As Integer = &H00400000  
Public Const     SPC_TMASK_PXI3          As Integer = &H00800000  
Public Const     SPC_TMASK_PXI4          As Integer = &H01000000  
Public Const     SPC_TMASK_PXI5          As Integer = &H02000000  
Public Const     SPC_TMASK_PXI6          As Integer = &H04000000  
Public Const     SPC_TMASK_PXI7          As Integer = &H08000000  
Public Const     SPC_TMASK_PXISTAR       As Integer = &H80000000

Public Const SPC_TRIG_CH_AVAILORMASK0    As Integer = 40450
Public Const SPC_TRIG_CH_AVAILORMASK1    As Integer = 40451
Public Const SPC_TRIG_CH_ORMASK0         As Integer = 40460
Public Const SPC_TRIG_CH_ORMASK1         As Integer = 40461
Public Const SPC_TRIG_CH_AVAILANDMASK0   As Integer = 40470
Public Const SPC_TRIG_CH_AVAILANDMASK1   As Integer = 40471
Public Const SPC_TRIG_CH_ANDMASK0        As Integer = 40480 
Public Const SPC_TRIG_CH_ANDMASK1        As Integer = 40481 
Public Const     SPC_TMASK0_CH0          As Integer = &H00000001
Public Const     SPC_TMASK0_CH1          As Integer = &H00000002
Public Const     SPC_TMASK0_CH2          As Integer = &H00000004
Public Const     SPC_TMASK0_CH3          As Integer = &H00000008
Public Const     SPC_TMASK0_CH4          As Integer = &H00000010
Public Const     SPC_TMASK0_CH5          As Integer = &H00000020
Public Const     SPC_TMASK0_CH6          As Integer = &H00000040
Public Const     SPC_TMASK0_CH7          As Integer = &H00000080
Public Const     SPC_TMASK0_CH8          As Integer = &H00000100
Public Const     SPC_TMASK0_CH9          As Integer = &H00000200
Public Const     SPC_TMASK0_CH10         As Integer = &H00000400
Public Const     SPC_TMASK0_CH11         As Integer = &H00000800
Public Const     SPC_TMASK0_CH12         As Integer = &H00001000
Public Const     SPC_TMASK0_CH13         As Integer = &H00002000
Public Const     SPC_TMASK0_CH14         As Integer = &H00004000
Public Const     SPC_TMASK0_CH15         As Integer = &H00008000
Public Const     SPC_TMASK0_CH16         As Integer = &H00010000
Public Const     SPC_TMASK0_CH17         As Integer = &H00020000
Public Const     SPC_TMASK0_CH18         As Integer = &H00040000
Public Const     SPC_TMASK0_CH19         As Integer = &H00080000
Public Const     SPC_TMASK0_CH20         As Integer = &H00100000
Public Const     SPC_TMASK0_CH21         As Integer = &H00200000
Public Const     SPC_TMASK0_CH22         As Integer = &H00400000
Public Const     SPC_TMASK0_CH23         As Integer = &H00800000
Public Const     SPC_TMASK0_CH24         As Integer = &H01000000
Public Const     SPC_TMASK0_CH25         As Integer = &H02000000
Public Const     SPC_TMASK0_CH26         As Integer = &H04000000
Public Const     SPC_TMASK0_CH27         As Integer = &H08000000
Public Const     SPC_TMASK0_CH28         As Integer = &H10000000
Public Const     SPC_TMASK0_CH29         As Integer = &H20000000
Public Const     SPC_TMASK0_CH30         As Integer = &H40000000
Public Const     SPC_TMASK0_CH31         As Integer = &H80000000

Public Const     SPC_TMASK1_CH32         As Integer = &H00000001
Public Const     SPC_TMASK1_CH33         As Integer = &H00000002
Public Const     SPC_TMASK1_CH34         As Integer = &H00000004
Public Const     SPC_TMASK1_CH35         As Integer = &H00000008
Public Const     SPC_TMASK1_CH36         As Integer = &H00000010
Public Const     SPC_TMASK1_CH37         As Integer = &H00000020
Public Const     SPC_TMASK1_CH38         As Integer = &H00000040
Public Const     SPC_TMASK1_CH39         As Integer = &H00000080
Public Const     SPC_TMASK1_CH40         As Integer = &H00000100
Public Const     SPC_TMASK1_CH41         As Integer = &H00000200
Public Const     SPC_TMASK1_CH42         As Integer = &H00000400
Public Const     SPC_TMASK1_CH43         As Integer = &H00000800
Public Const     SPC_TMASK1_CH44         As Integer = &H00001000
Public Const     SPC_TMASK1_CH45         As Integer = &H00002000
Public Const     SPC_TMASK1_CH46         As Integer = &H00004000
Public Const     SPC_TMASK1_CH47         As Integer = &H00008000
Public Const     SPC_TMASK1_CH48         As Integer = &H00010000
Public Const     SPC_TMASK1_CH49         As Integer = &H00020000
Public Const     SPC_TMASK1_CH50         As Integer = &H00040000
Public Const     SPC_TMASK1_CH51         As Integer = &H00080000
Public Const     SPC_TMASK1_CH52         As Integer = &H00100000
Public Const     SPC_TMASK1_CH53         As Integer = &H00200000
Public Const     SPC_TMASK1_CH54         As Integer = &H00400000
Public Const     SPC_TMASK1_CH55         As Integer = &H00800000
Public Const     SPC_TMASK1_CH56         As Integer = &H01000000
Public Const     SPC_TMASK1_CH57         As Integer = &H02000000
Public Const     SPC_TMASK1_CH58         As Integer = &H04000000
Public Const     SPC_TMASK1_CH59         As Integer = &H08000000
Public Const     SPC_TMASK1_CH60         As Integer = &H10000000
Public Const     SPC_TMASK1_CH61         As Integer = &H20000000
Public Const     SPC_TMASK1_CH62         As Integer = &H40000000
Public Const     SPC_TMASK1_CH63         As Integer = &H80000000

Public Const SPC_TRIG_EXT_AVAILMODES     As Integer = 40500
Public Const SPC_TRIG_EXT0_MODE          As Integer = 40510
Public Const SPC_TRIG_EXT1_MODE          As Integer = 40511
Public Const SPC_TRIG_XIO_AVAILMODES     As Integer = 40550
Public Const SPC_TRIG_XIO0_MODE          As Integer = 40560
Public Const SPC_TRIG_XIO1_MODE          As Integer = 40561
Public Const     SPC_TM_MODEMASK         As Integer = &H00FFFFFF
Public Const     SPC_TM_NONE             As Integer = &H00000000
Public Const     SPC_TM_POS              As Integer = &H00000001
Public Const     SPC_TM_NEG              As Integer = &H00000002
Public Const     SPC_TM_BOTH             As Integer = &H00000004
Public Const     SPC_TM_HIGH             As Integer = &H00000008
Public Const     SPC_TM_LOW              As Integer = &H00000010
Public Const     SPC_TM_WINENTER         As Integer = &H00000020
Public Const     SPC_TM_WINLEAVE         As Integer = &H00000040
Public Const     SPC_TM_INWIN            As Integer = &H00000080
Public Const     SPC_TM_OUTSIDEWIN       As Integer = &H00000100
Public Const     SPC_TM_SPIKE            As Integer = &H00000200
Public Const     SPC_TM_PATTERN          As Integer = &H00000400
Public Const     SPC_TM_STEEPPOS         As Integer = &H00000800
Public Const     SPC_TM_STEEPNEG         As Integer = &H00001000
Public Const     SPC_TM_EXTRAMASK        As Integer = &HFF000000
Public Const     SPC_TM_REARM            As Integer = &H01000000
Public Const     SPC_TM_PW_SMALLER       As Integer = &H02000000
Public Const     SPC_TM_PW_GREATER       As Integer = &H04000000
Public Const     SPC_TM_DOUBLEEDGE       As Integer = &H08000000

Public Const SPC_TRIG_PATTERN_AVAILMODES As Integer = 40580
Public Const SPC_TRIG_PATTERN_MODE       As Integer = 40590

Public Const SPC_TRIG_CH_AVAILMODES      As Integer = 40600
Public Const SPC_TRIG_CH0_MODE           As Integer = 40610
Public Const SPC_TRIG_CH1_MODE           As Integer = 40611
Public Const SPC_TRIG_CH2_MODE           As Integer = 40612
Public Const SPC_TRIG_CH3_MODE           As Integer = 40613
Public Const SPC_TRIG_CH4_MODE           As Integer = 40614
Public Const SPC_TRIG_CH5_MODE           As Integer = 40615
Public Const SPC_TRIG_CH6_MODE           As Integer = 40616
Public Const SPC_TRIG_CH7_MODE           As Integer = 40617
Public Const SPC_TRIG_CH8_MODE           As Integer = 40618
Public Const SPC_TRIG_CH9_MODE           As Integer = 40619
Public Const SPC_TRIG_CH10_MODE          As Integer = 40620
Public Const SPC_TRIG_CH11_MODE          As Integer = 40621
Public Const SPC_TRIG_CH12_MODE          As Integer = 40622
Public Const SPC_TRIG_CH13_MODE          As Integer = 40623
Public Const SPC_TRIG_CH14_MODE          As Integer = 40624
Public Const SPC_TRIG_CH15_MODE          As Integer = 40625
Public Const SPC_TRIG_CH16_MODE          As Integer = 40626
Public Const SPC_TRIG_CH17_MODE          As Integer = 40627
Public Const SPC_TRIG_CH18_MODE          As Integer = 40628
Public Const SPC_TRIG_CH19_MODE          As Integer = 40629
Public Const SPC_TRIG_CH20_MODE          As Integer = 40630
Public Const SPC_TRIG_CH21_MODE          As Integer = 40631
Public Const SPC_TRIG_CH22_MODE          As Integer = 40632
Public Const SPC_TRIG_CH23_MODE          As Integer = 40633
Public Const SPC_TRIG_CH24_MODE          As Integer = 40634
Public Const SPC_TRIG_CH25_MODE          As Integer = 40635
Public Const SPC_TRIG_CH26_MODE          As Integer = 40636
Public Const SPC_TRIG_CH27_MODE          As Integer = 40637
Public Const SPC_TRIG_CH28_MODE          As Integer = 40638
Public Const SPC_TRIG_CH29_MODE          As Integer = 40639
Public Const SPC_TRIG_CH30_MODE          As Integer = 40640
Public Const SPC_TRIG_CH31_MODE          As Integer = 40641

Public Const SPC_TRIG_CH32_MODE          As Integer = 40642
Public Const SPC_TRIG_CH33_MODE          As Integer = 40643
Public Const SPC_TRIG_CH34_MODE          As Integer = 40644
Public Const SPC_TRIG_CH35_MODE          As Integer = 40645
Public Const SPC_TRIG_CH36_MODE          As Integer = 40646
Public Const SPC_TRIG_CH37_MODE          As Integer = 40647
Public Const SPC_TRIG_CH38_MODE          As Integer = 40648
Public Const SPC_TRIG_CH39_MODE          As Integer = 40649
Public Const SPC_TRIG_CH40_MODE          As Integer = 40650
Public Const SPC_TRIG_CH41_MODE          As Integer = 40651
Public Const SPC_TRIG_CH42_MODE          As Integer = 40652
Public Const SPC_TRIG_CH43_MODE          As Integer = 40653
Public Const SPC_TRIG_CH44_MODE          As Integer = 40654
Public Const SPC_TRIG_CH45_MODE          As Integer = 40655
Public Const SPC_TRIG_CH46_MODE          As Integer = 40656
Public Const SPC_TRIG_CH47_MODE          As Integer = 40657
Public Const SPC_TRIG_CH48_MODE          As Integer = 40658
Public Const SPC_TRIG_CH49_MODE          As Integer = 40659
Public Const SPC_TRIG_CH50_MODE          As Integer = 40660
Public Const SPC_TRIG_CH51_MODE          As Integer = 40661
Public Const SPC_TRIG_CH52_MODE          As Integer = 40662
Public Const SPC_TRIG_CH53_MODE          As Integer = 40663
Public Const SPC_TRIG_CH54_MODE          As Integer = 40664
Public Const SPC_TRIG_CH55_MODE          As Integer = 40665
Public Const SPC_TRIG_CH56_MODE          As Integer = 40666
Public Const SPC_TRIG_CH57_MODE          As Integer = 40667
Public Const SPC_TRIG_CH58_MODE          As Integer = 40668
Public Const SPC_TRIG_CH59_MODE          As Integer = 40669
Public Const SPC_TRIG_CH60_MODE          As Integer = 40670
Public Const SPC_TRIG_CH61_MODE          As Integer = 40671
Public Const SPC_TRIG_CH62_MODE          As Integer = 40672
Public Const SPC_TRIG_CH63_MODE          As Integer = 40673


Public Const SPC_TRIG_AVAILDELAY         As Integer = 40800
Public Const SPC_TRIG_DELAY              As Integer = 40810

Public Const SPC_SINGLESHOT              As Integer = 41000
Public Const SPC_OUTONTRIGGER            As Integer = 41100
Public Const SPC_RESTARTCONT             As Integer = 41200
Public Const SPC_SINGLERESTART			As Integer = 41300

Public Const SPC_TRIGGERLEVEL            As Integer = 42000
Public Const SPC_TRIGGERLEVEL0           As Integer = 42000
Public Const SPC_TRIGGERLEVEL1           As Integer = 42001
Public Const SPC_TRIGGERLEVEL2           As Integer = 42002
Public Const SPC_TRIGGERLEVEL3           As Integer = 42003
Public Const SPC_TRIGGERLEVEL4           As Integer = 42004
Public Const SPC_TRIGGERLEVEL5           As Integer = 42005
Public Const SPC_TRIGGERLEVEL6           As Integer = 42006
Public Const SPC_TRIGGERLEVEL7           As Integer = 42007
Public Const SPC_TRIGGERLEVEL8           As Integer = 42008
Public Const SPC_TRIGGERLEVEL9           As Integer = 42009
Public Const SPC_TRIGGERLEVEL10          As Integer = 42010
Public Const SPC_TRIGGERLEVEL11          As Integer = 42011
Public Const SPC_TRIGGERLEVEL12          As Integer = 42012
Public Const SPC_TRIGGERLEVEL13          As Integer = 42013
Public Const SPC_TRIGGERLEVEL14          As Integer = 42014
Public Const SPC_TRIGGERLEVEL15          As Integer = 42015

Public Const SPC_AVAILHIGHLEVEL_MIN      As Integer = 41997
Public Const SPC_AVAILHIGHLEVEL_MAX      As Integer = 41998
Public Const SPC_AVAILHIGHLEVEL_STEP     As Integer = 41999

Public Const SPC_HIGHLEVEL0              As Integer = 42000
Public Const SPC_HIGHLEVEL1              As Integer = 42001
Public Const SPC_HIGHLEVEL2              As Integer = 42002
Public Const SPC_HIGHLEVEL3              As Integer = 42003
Public Const SPC_HIGHLEVEL4              As Integer = 42004
Public Const SPC_HIGHLEVEL5              As Integer = 42005
Public Const SPC_HIGHLEVEL6              As Integer = 42006
Public Const SPC_HIGHLEVEL7              As Integer = 42007
Public Const SPC_HIGHLEVEL8              As Integer = 42008
Public Const SPC_HIGHLEVEL9              As Integer = 42009
Public Const SPC_HIGHLEVEL10             As Integer = 42010
Public Const SPC_HIGHLEVEL11             As Integer = 42011
Public Const SPC_HIGHLEVEL12             As Integer = 42012
Public Const SPC_HIGHLEVEL13             As Integer = 42013
Public Const SPC_HIGHLEVEL14             As Integer = 42014
Public Const SPC_HIGHLEVEL15             As Integer = 42015

Public Const SPC_AVAILLOWLEVEL_MIN       As Integer = 42097
Public Const SPC_AVAILLOWLEVEL_MAX       As Integer = 42098
Public Const SPC_AVAILLOWLEVEL_STEP      As Integer = 42099

Public Const SPC_LOWLEVEL0               As Integer = 42100
Public Const SPC_LOWLEVEL1               As Integer = 42101
Public Const SPC_LOWLEVEL2               As Integer = 42102
Public Const SPC_LOWLEVEL3               As Integer = 42103
Public Const SPC_LOWLEVEL4               As Integer = 42104
Public Const SPC_LOWLEVEL5               As Integer = 42105
Public Const SPC_LOWLEVEL6               As Integer = 42106
Public Const SPC_LOWLEVEL7               As Integer = 42107
Public Const SPC_LOWLEVEL8               As Integer = 42108
Public Const SPC_LOWLEVEL9               As Integer = 42109
Public Const SPC_LOWLEVEL10              As Integer = 42110
Public Const SPC_LOWLEVEL11              As Integer = 42111
Public Const SPC_LOWLEVEL12              As Integer = 42112
Public Const SPC_LOWLEVEL13              As Integer = 42113
Public Const SPC_LOWLEVEL14              As Integer = 42114
Public Const SPC_LOWLEVEL15              As Integer = 42115

Public Const SPC_TRIG_CH0_LEVEL0         As Integer = 42200
Public Const SPC_TRIG_CH1_LEVEL0         As Integer = 42201
Public Const SPC_TRIG_CH2_LEVEL0         As Integer = 42202
Public Const SPC_TRIG_CH3_LEVEL0         As Integer = 42203
Public Const SPC_TRIG_CH4_LEVEL0         As Integer = 42204
Public Const SPC_TRIG_CH5_LEVEL0         As Integer = 42205
Public Const SPC_TRIG_CH6_LEVEL0         As Integer = 42206
Public Const SPC_TRIG_CH7_LEVEL0         As Integer = 42207
Public Const SPC_TRIG_CH8_LEVEL0         As Integer = 42208
Public Const SPC_TRIG_CH9_LEVEL0         As Integer = 42209
Public Const SPC_TRIG_CH10_LEVEL0        As Integer = 42210
Public Const SPC_TRIG_CH11_LEVEL0        As Integer = 42211
Public Const SPC_TRIG_CH12_LEVEL0        As Integer = 42212
Public Const SPC_TRIG_CH13_LEVEL0        As Integer = 42213
Public Const SPC_TRIG_CH14_LEVEL0        As Integer = 42214
Public Const SPC_TRIG_CH15_LEVEL0        As Integer = 42215

Public Const SPC_TRIG_CH0_LEVEL1         As Integer = 42300
Public Const SPC_TRIG_CH1_LEVEL1         As Integer = 42301
Public Const SPC_TRIG_CH2_LEVEL1         As Integer = 42302
Public Const SPC_TRIG_CH3_LEVEL1         As Integer = 42303
Public Const SPC_TRIG_CH4_LEVEL1         As Integer = 42304
Public Const SPC_TRIG_CH5_LEVEL1         As Integer = 42305
Public Const SPC_TRIG_CH6_LEVEL1         As Integer = 42306
Public Const SPC_TRIG_CH7_LEVEL1         As Integer = 42307
Public Const SPC_TRIG_CH8_LEVEL1         As Integer = 42308
Public Const SPC_TRIG_CH9_LEVEL1         As Integer = 42309
Public Const SPC_TRIG_CH10_LEVEL1        As Integer = 42310
Public Const SPC_TRIG_CH11_LEVEL1        As Integer = 42311
Public Const SPC_TRIG_CH12_LEVEL1        As Integer = 42312
Public Const SPC_TRIG_CH13_LEVEL1        As Integer = 42313
Public Const SPC_TRIG_CH14_LEVEL1        As Integer = 42314
Public Const SPC_TRIG_CH15_LEVEL1        As Integer = 42315

Public Const SPC_TRIGGERPATTERN          As Integer = 43000
Public Const SPC_TRIGGERPATTERN0         As Integer = 43000
Public Const SPC_TRIGGERPATTERN1         As Integer = 43001
Public Const SPC_TRIGGERMASK             As Integer = 43100
Public Const SPC_TRIGGERMASK0            As Integer = 43100
Public Const SPC_TRIGGERMASK1            As Integer = 43101

Public Const SPC_PULSEWIDTH              As Integer = 44000
Public Const SPC_PULSEWIDTH0             As Integer = 44000
Public Const SPC_PULSEWIDTH1             As Integer = 44001

Public Const SPC_TRIG_CH_AVAILPULSEWIDTH As Integer = 44100
Public Const SPC_TRIG_CH_PULSEWIDTH      As Integer = 44101
Public Const SPC_TRIG_CH0_PULSEWIDTH     As Integer = 44101
Public Const SPC_TRIG_CH1_PULSEWIDTH     As Integer = 44102
Public Const SPC_TRIG_CH2_PULSEWIDTH     As Integer = 44103
Public Const SPC_TRIG_CH3_PULSEWIDTH     As Integer = 44104
Public Const SPC_TRIG_CH4_PULSEWIDTH     As Integer = 44105
Public Const SPC_TRIG_CH5_PULSEWIDTH     As Integer = 44106
Public Const SPC_TRIG_CH6_PULSEWIDTH     As Integer = 44107
Public Const SPC_TRIG_CH7_PULSEWIDTH     As Integer = 44108
Public Const SPC_TRIG_CH8_PULSEWIDTH     As Integer = 44109
Public Const SPC_TRIG_CH9_PULSEWIDTH     As Integer = 44110
Public Const SPC_TRIG_CH10_PULSEWIDTH    As Integer = 44111
Public Const SPC_TRIG_CH11_PULSEWIDTH    As Integer = 44112
Public Const SPC_TRIG_CH12_PULSEWIDTH    As Integer = 44113
Public Const SPC_TRIG_CH13_PULSEWIDTH    As Integer = 44114
Public Const SPC_TRIG_CH14_PULSEWIDTH    As Integer = 44115
Public Const SPC_TRIG_CH15_PULSEWIDTH    As Integer = 44116

Public Const SPC_TRIG_EXT_AVAILPULSEWIDTH As Integer = 44200
Public Const SPC_TRIG_EXT0_PULSEWIDTH    As Integer = 44210


Public Const SPC_READTROFFSET            As Integer = 45000
Public Const SPC_TRIGGEREDGE             As Integer = 46000
Public Const SPC_TRIGGEREDGE0            As Integer = 46000
Public Const SPC_TRIGGEREDGE1            As Integer = 46001
Public Const     TE_POS                  As Integer = 10000
Public Const     TE_NEG                  As Integer = 10010
Public Const     TE_BOTH                 As Integer = 10020
Public Const     TE_NONE                 As Integer = 10030


' ----- Timestamp -----
Public Const CH_TIMESTAMP                As Integer = 9999

Public Const SPC_TIMESTAMP_CMD           As Integer = 47000
Public Const     TS_RESET                    As Integer = 0
Public Const     TS_MODE_DISABLE             As Integer = 10
Public Const     TS_MODE_STARTRESET          As Integer = 11
Public Const     TS_MODE_STANDARD            As Integer = 12
Public Const     TS_MODE_REFCLOCK            As Integer = 13
Public Const     TS_MODE_TEST5555            As Integer = 90
Public Const     TS_MODE_TESTAAAA            As Integer = 91
Public Const     TS_MODE_ZHTEST              As Integer = 92

' ----- modes for M2i hardware (bitmap) -----
Public Const SPC_TIMESTAMP_AVAILMODES    As Integer = 47001
Public Const     SPC_TSMODE_DISABLE      As Integer = &H00000000
Public Const     SPC_TS_RESET            As Integer = &H00000001
Public Const     SPC_TSMODE_STANDARD     As Integer = &H00000002
Public Const     SPC_TSMODE_STARTRESET   As Integer = &H00000004
Public Const     SPC_TSCNT_INTERNAL      As Integer = &H00000100
Public Const     SPC_TSCNT_REFCLOCKPOS   As Integer = &H00000200
Public Const     SPC_TSCNT_REFCLOCKNEG   As Integer = &H00000400

Public Const     SPC_TSXIOACQ_DISABLE    As Integer = &H00000000
Public Const     SPC_TSXIOACQ_ENABLE     As Integer = &H00001000

Public Const     SPC_TSMODE_MASK         As Integer = &H000000FF
Public Const     SPC_TSCNT_MASK          As Integer = &H00000F00


Public Const SPC_TIMESTAMP_STATUS        As Integer = 47010
Public Const     TS_FIFO_EMPTY               As Integer = 0
Public Const     TS_FIFO_LESSHALF            As Integer = 1
Public Const     TS_FIFO_MOREHALF            As Integer = 2
Public Const     TS_FIFO_OVERFLOW            As Integer = 3

Public Const SPC_TIMESTAMP_COUNT         As Integer = 47020
Public Const SPC_TIMESTAMP_STARTTIME     As Integer = 47030
Public Const SPC_TIMESTAMP_STARTDATE     As Integer = 47031
Public Const SPC_TIMESTAMP_FIFO          As Integer = 47040
Public Const SPC_TIMESTAMP_TIMEOUT       As Integer = 47045

Public Const SPC_TIMESTAMP_RESETMODE     As Integer = 47050
Public Const     TS_RESET_POS               As Integer = 10
Public Const     TS_RESET_NEG               As Integer = 20



' ----- Extra I/O module -----
Public Const SPC_XIO_DIRECTION           As Integer = 47100
Public Const     XD_CH0_INPUT                As Integer = 0
Public Const     XD_CH0_OUTPUT               As Integer = 1
Public Const     XD_CH1_INPUT                As Integer = 0
Public Const     XD_CH1_OUTPUT               As Integer = 2
Public Const     XD_CH2_INPUT                As Integer = 0
Public Const     XD_CH2_OUTPUT               As Integer = 4
Public Const SPC_XIO_DIGITALIO           As Integer = 47110
Public Const SPC_XIO_ANALOGOUT0          As Integer = 47120
Public Const SPC_XIO_ANALOGOUT1          As Integer = 47121
Public Const SPC_XIO_ANALOGOUT2          As Integer = 47122
Public Const SPC_XIO_ANALOGOUT3          As Integer = 47123
Public Const SPC_XIO_WRITEDACS           As Integer = 47130



' ----- Star-Hub -----
Public Const SPC_STARHUB_CMD             As Integer = 48000
Public Const     SH_INIT                     As Integer = 0  ' Internal use: Initialisation of Starhub
Public Const     SH_AUTOROUTE                As Integer = 1  ' Internal use: Routing of Starhub
Public Const     SH_INITDONE                 As Integer = 2  ' Internal use: End of Init
Public Const     SH_SYNCSTART                As Integer = 3  ' Internal use: Synchronisation

Public Const SPC_STARHUB_STATUS          As Integer = 48010

Public Const SPC_STARHUB_ROUTE0          As Integer = 48100  ' Routing Information for Test
Public Const SPC_STARHUB_ROUTE99         As Integer = 48199  ' ...




' ----- Gain and Offset Adjust DAC's -----
Public Const SPC_ADJ_START               As Integer = 50000

Public Const SPC_ADJ_LOAD                As Integer = 50000
Public Const SPC_ADJ_SAVE                As Integer = 50010
Public Const     ADJ_DEFAULT                 As Integer = 0
Public Const     ADJ_USER0                   As Integer = 1
Public Const     ADJ_USER1                   As Integer = 2
Public Const     ADJ_USER2                   As Integer = 3
Public Const     ADJ_USER3                   As Integer = 4
Public Const     ADJ_USER4                   As Integer = 5
Public Const     ADJ_USER5                   As Integer = 6
Public Const     ADJ_USER6                   As Integer = 7
Public Const     ADJ_USER7                   As Integer = 8

Public Const SPC_ADJ_AUTOADJ             As Integer = 50020
Public Const     ADJ_ALL                     As Integer = 0
Public Const     ADJ_CURRENT                 As Integer = 1

Public Const SPC_ADJ_SET                 As Integer = 50030
Public Const SPC_ADJ_FAILMASK            As Integer = 50040

Public Const SPC_ADJ_CALIBSOURCE			As Integer = 50050
Public Const		ADJ_CALSRC_OFF				As Integer = 0
Public Const		ADJ_CALSRC_GND			   As Integer = -1
Public Const		ADJ_CALSRC_GNDOFFS		   As Integer = -2

Public Const SPC_ADJ_CALIBVALUE0			As Integer = 50060
Public Const SPC_ADJ_CALIBVALUE1			As Integer = 50061
Public Const SPC_ADJ_CALIBVALUE2			As Integer = 50062
Public Const SPC_ADJ_CALIBVALUE3			As Integer = 50063
Public Const SPC_ADJ_CALIBVALUE4			As Integer = 50064
Public Const SPC_ADJ_CALIBVALUE5			As Integer = 50065
Public Const SPC_ADJ_CALIBVALUE6			As Integer = 50066
Public Const SPC_ADJ_CALIBVALUE7			As Integer = 50067


Public Const SPC_ADJ_OFFSET0             As Integer = 51000
Public Const SPC_ADJ_OFFSET999           As Integer = 51999

Public Const SPC_ADJ_GAIN0               As Integer = 52000
Public Const SPC_ADJ_GAIN999             As Integer = 52999

Public Const SPC_ADJ_CORRECT0            As Integer = 53000
Public Const SPC_ADJ_OFFS_CORRECT0       As Integer = 53000
Public Const SPC_ADJ_CORRECT999          As Integer = 53999
Public Const SPC_ADJ_OFFS_CORRECT999     As Integer = 53999

Public Const SPC_ADJ_XIOOFFS0            As Integer = 54000
Public Const SPC_ADJ_XIOOFFS1            As Integer = 54001
Public Const SPC_ADJ_XIOOFFS2            As Integer = 54002
Public Const SPC_ADJ_XIOOFFS3            As Integer = 54003

Public Const SPC_ADJ_XIOGAIN0            As Integer = 54010
Public Const SPC_ADJ_XIOGAIN1            As Integer = 54011
Public Const SPC_ADJ_XIOGAIN2            As Integer = 54012
Public Const SPC_ADJ_XIOGAIN3            As Integer = 54013

Public Const SPC_ADJ_GAIN_CORRECT0       As Integer = 55000
Public Const SPC_ADJ_GAIN_CORRECT999     As Integer = 55999

Public Const SPC_ADJ_END                 As Integer = 59999



' ----- FIFO Control -----
Public Const SPC_FIFO_BUFFERS            As Integer = 60000          ' number of FIFO buffers
Public Const SPC_FIFO_BUFLEN             As Integer = 60010          ' len of each FIFO buffer
Public Const SPC_FIFO_BUFCOUNT           As Integer = 60020          ' number of FIFO buffers tranfered until now
Public Const SPC_FIFO_BUFMAXCNT          As Integer = 60030          ' number of FIFO buffers to be transfered (0=continuous)
Public Const SPC_FIFO_BUFADRCNT          As Integer = 60040          ' number of FIFO buffers allowed
Public Const SPC_FIFO_BUFREADY           As Integer = 60050          ' fifo buffer ready register (same as SPC_COMMAND + SPC_FIFO_BUFREADY0...)
Public Const SPC_FIFO_BUFADR0            As Integer = 60100          ' adress of FIFO buffer no. 0
Public Const SPC_FIFO_BUFADR1            As Integer = 60101          ' ...
Public Const SPC_FIFO_BUFADR2            As Integer = 60102          ' ...
Public Const SPC_FIFO_BUFADR3            As Integer = 60103          ' ...
Public Const SPC_FIFO_BUFADR4            As Integer = 60104          ' ...
Public Const SPC_FIFO_BUFADR5            As Integer = 60105          ' ...
Public Const SPC_FIFO_BUFADR6            As Integer = 60106          ' ...
Public Const SPC_FIFO_BUFADR7            As Integer = 60107          ' ...
Public Const SPC_FIFO_BUFADR8            As Integer = 60108          ' ...
Public Const SPC_FIFO_BUFADR9            As Integer = 60109          ' ...
Public Const SPC_FIFO_BUFADR10           As Integer = 60110          ' ...
Public Const SPC_FIFO_BUFADR11           As Integer = 60111          ' ...
Public Const SPC_FIFO_BUFADR12           As Integer = 60112          ' ...
Public Const SPC_FIFO_BUFADR13           As Integer = 60113          ' ...
Public Const SPC_FIFO_BUFADR14           As Integer = 60114          ' ...
Public Const SPC_FIFO_BUFADR15           As Integer = 60115          ' ...
Public Const SPC_FIFO_BUFADR255          As Integer = 60355          ' last



' ----- Filter -----
Public Const SPC_FILTER                  As Integer = 100000



' ----- Pattern -----
Public Const SPC_PATTERNENABLE           As Integer = 110000
Public Const SPC_READDIGITAL             As Integer = 110100



' ----- Miscellanous -----
Public Const SPC_MISCDAC0                As Integer = 200000
Public Const SPC_MISCDAC1                As Integer = 200010
Public Const SPC_FACTORYMODE             As Integer = 200020
Public Const SPC_DIRECTDAC               As Integer = 200030
Public Const SPC_NOTRIGSYNC              As Integer = 200040
Public Const SPC_DSPDIRECT               As Integer = 200100
Public Const SPC_DMAPHYSICALADR          As Integer = 200110
Public Const SPC_MICXCOMPATIBILITYMODE   As Integer = 200120
Public Const SPC_TEST_FIFOSPEED          As Integer = 200121
Public Const SPC_RELOADDEMO              As Integer = 200122
Public Const SPC_OVERSAMPLINGFACTOR		As Integer = 200123
Public Const SPC_XYZMODE                 As Integer = 200200
Public Const SPC_INVERTDATA              As Integer = 200300
Public Const SPC_GATEMARKENABLE          As Integer = 200400
Public Const SPC_EXPANDINT32             As Integer = 200500
Public Const SPC_NOPRETRIGGER            As Integer = 200600
Public Const SPC_RELAISWAITTIME          As Integer = 200700
Public Const SPC_DACWAITTIME             As Integer = 200710
Public Const SPC_ILAMODE                 As Integer = 200800
Public Const SPC_NMDGMODE                As Integer = 200810
Public Const SPC_CKADHALF_OUTPUT         As Integer = 200820
Public Const SPC_LONGTRIG_OUTPUT         As Integer = 200830
Public Const SPC_ENHANCEDSTATUS          As Integer = 200900
Public Const SPC_FILLSIZEPROMILLE        As Integer = 200910
Public Const SPC_OVERRANGEBIT            As Integer = 201000
Public Const SPC_2CH8BITMODE             As Integer = 201100
Public Const SPC_12BITMODE               As Integer = 201200
Public Const SPC_HOLDLASTSAMPLE          As Integer = 201300
Public Const SPC_CKSYNC0                 As Integer = 202000
Public Const SPC_CKSYNC1                 As Integer = 202001
Public Const SPC_DISABLEMOD0             As Integer = 203000
Public Const SPC_DISABLEMOD1             As Integer = 203010
Public Const SPC_ENABLEOVERRANGECHECK    As Integer = 204000
Public Const SPC_OVERRANGESTATUS         As Integer = 204010
Public Const SPC_BITMODE                 As Integer = 205000

Public Const SPC_READBACK                As Integer = 206000
Public Const SPC_AVAILSTOPLEVEL          As Integer = 206009
Public Const SPC_STOPLEVEL1              As Integer = 206010
Public Const SPC_STOPLEVEL0              As Integer = 206020
Public Const SPC_CH0_STOPLEVEL           As Integer = 206020
Public Const SPC_CH1_STOPLEVEL           As Integer = 206021
Public Const SPC_CH2_STOPLEVEL           As Integer = 206022
Public Const SPC_CH3_STOPLEVEL           As Integer = 206023
Public Const     SPCM_STOPLVL_TRISTATE   As Integer = &H00000001
Public Const     SPCM_STOPLVL_LOW        As Integer = &H00000002
Public Const     SPCM_STOPLVL_HIGH       As Integer = &H00000004
Public Const     SPCM_STOPLVL_HOLDLAST   As Integer = &H00000008

Public Const SPC_DIFFMODE                As Integer = 206030
Public Const SPC_DACADJUST               As Integer = 206040

Public Const	SPC_AMP_MODE				As Integer = 207000

Public Const SPCM_FW_CTRL                As Integer = 210000
Public Const SPCM_FW_CLOCK               As Integer = 210010
Public Const SPCM_FW_CONFIG              As Integer = 210020
Public Const SPCM_FW_MODULEA             As Integer = 210030
Public Const SPCM_FW_MODEXTRA            As Integer = 210050

Public Const SPC_MULTI                   As Integer = 220000
Public Const SPC_DOUBLEMEM               As Integer = 220100
Public Const SPC_MULTIMEMVALID           As Integer = 220200
Public Const SPC_BANK                    As Integer = 220300
Public Const SPC_GATE                    As Integer = 220400
Public Const SPC_RELOAD                  As Integer = 230000
Public Const SPC_USEROUT                 As Integer = 230010
Public Const SPC_WRITEUSER0              As Integer = 230100
Public Const SPC_WRITEUSER1              As Integer = 230110
Public Const SPC_READUSER0               As Integer = 230200
Public Const SPC_READUSER1               As Integer = 230210
Public Const SPC_MUX                     As Integer = 240000
Public Const SPC_ADJADC                  As Integer = 241000
Public Const SPC_ADJOFFS0                As Integer = 242000
Public Const SPC_ADJOFFS1                As Integer = 243000
Public Const SPC_ADJGAIN0                As Integer = 244000
Public Const SPC_ADJGAIN1                As Integer = 245000
Public Const SPC_READEPROM               As Integer = 250000
Public Const SPC_WRITEEPROM              As Integer = 250010
Public Const SPC_DIRECTIO                As Integer = 260000
Public Const SPC_DIRECT_MODA             As Integer = 260010
Public Const SPC_DIRECT_MODB             As Integer = 260020
Public Const SPC_DIRECT_EXT0             As Integer = 260030
Public Const SPC_DIRECT_EXT1             As Integer = 260031
Public Const SPC_DIRECT_EXT2             As Integer = 260032
Public Const SPC_DIRECT_EXT3             As Integer = 260033
Public Const SPC_DIRECT_EXT4             As Integer = 260034
Public Const SPC_DIRECT_EXT5             As Integer = 260035
Public Const SPC_DIRECT_EXT6             As Integer = 260036
Public Const SPC_DIRECT_EXT7             As Integer = 260037
Public Const SPC_MEMTEST                 As Integer = 270000
Public Const SPC_NODMA                   As Integer = 275000
Public Const SPC_NOCOUNTER               As Integer = 275010
Public Const SPC_NOSCATTERGATHER         As Integer = 275020
Public Const SPC_RUNINTENABLE            As Integer = 290000
Public Const SPC_XFERBUFSIZE             As Integer = 295000
Public Const SPC_CHLX                    As Integer = 295010
Public Const SPC_SPECIALCLOCK            As Integer = 295100
Public Const SPC_STARTDELAY              As Integer = 295110
Public Const SPC_BASISTTLTRIG            As Integer = 295120
Public Const SPC_TIMEOUT                 As Integer = 295130
Public Const SPC_LOGDLLCALLS             As Integer = 299999






' ----- PCK400 -----
Public Const SPC_FREQUENCE               As Integer = 300000
Public Const SPC_DELTAFREQUENCE          As Integer = 300010
Public Const SPC_PINHIGH                 As Integer = 300100
Public Const SPC_PINLOW                  As Integer = 300110
Public Const SPC_PINDELTA                As Integer = 300120
Public Const SPC_STOPLEVEL               As Integer = 300200
Public Const SPC_PINRELAIS               As Integer = 300210
Public Const SPC_EXTERNLEVEL             As Integer = 300300



' ----- PADCO -----
Public Const SPC_COUNTER0                As Integer = 310000
Public Const SPC_COUNTER1                As Integer = 310001
Public Const SPC_COUNTER2                As Integer = 310002
Public Const SPC_COUNTER3                As Integer = 310003
Public Const SPC_COUNTER4                As Integer = 310004
Public Const SPC_COUNTER5                As Integer = 310005
Public Const SPC_MODE0                   As Integer = 310100
Public Const SPC_MODE1                   As Integer = 310101
Public Const SPC_MODE2                   As Integer = 310102
Public Const SPC_MODE3                   As Integer = 310103
Public Const SPC_MODE4                   As Integer = 310104
Public Const SPC_MODE5                   As Integer = 310105
Public Const     CM_SINGLE                   As Integer = 1
Public Const     CM_MULTI                    As Integer = 2
Public Const     CM_POSEDGE                  As Integer = 4
Public Const     CM_NEGEDGE                  As Integer = 8
Public Const     CM_HIGHPULSE                As Integer = 16
Public Const     CM_LOWPULSE                 As Integer = 32



' ----- PAD1616 -----
Public Const SPC_SEQUENCERESET           As Integer = 320000
Public Const SPC_SEQUENCEADD             As Integer = 320010
Public Const     SEQ_IR_10000MV              As Integer = 0
Public Const     SEQ_IR_5000MV               As Integer = 1
Public Const     SEQ_IR_2000MV               As Integer = 2
Public Const     SEQ_IR_1000MV               As Integer = 3
Public Const     SEQ_IR_500MV                As Integer = 4
Public Const     SEQ_CH0                     As Integer = 0
Public Const     SEQ_CH1                     As Integer = 8
Public Const     SEQ_CH2                     As Integer = 16
Public Const     SEQ_CH3                     As Integer = 24
Public Const     SEQ_CH4                     As Integer = 32
Public Const     SEQ_CH5                     As Integer = 40
Public Const     SEQ_CH6                     As Integer = 48
Public Const     SEQ_CH7                     As Integer = 56
Public Const     SEQ_CH8                     As Integer = 64
Public Const     SEQ_CH9                     As Integer = 72
Public Const     SEQ_CH10                    As Integer = 80
Public Const     SEQ_CH11                    As Integer = 88
Public Const     SEQ_CH12                    As Integer = 96
Public Const     SEQ_CH13                    As Integer = 104
Public Const     SEQ_CH14                    As Integer = 112
Public Const     SEQ_CH15                    As Integer = 120
Public Const     SEQ_TRIGGER                 As Integer = 128
Public Const     SEQ_START                   As Integer = 256



' ----- Option CA -----
Public Const SPC_CA_MODE                 As Integer = 330000
Public Const     CAMODE_OFF                  As Integer = 0
Public Const     CAMODE_CDM                  As Integer = 1
Public Const     CAMODE_KW                   As Integer = 2
Public Const     CAMODE_OT                   As Integer = 3
Public Const     CAMODE_CDMMUL               As Integer = 4
Public Const SPC_CA_TRIGDELAY            As Integer = 330010
Public Const SPC_CA_CKDIV                As Integer = 330020
Public Const SPC_CA_PULS                 As Integer = 330030
Public Const SPC_CA_CKMUL                As Integer = 330040
Public Const SPC_CA_DREHZAHLFORMAT       As Integer = 330050
Public Const     CADREH_4X4                  As Integer = 0
Public Const     CADREH_1X16                 As Integer = 1
Public Const SPC_CA_KWINVERT             As Integer = 330060
Public Const SPC_CA_OUTA                 As Integer = 330100
Public Const SPC_CA_OUTB                 As Integer = 330110
Public Const     CAOUT_TRISTATE              As Integer = 0
Public Const     CAOUT_LOW                   As Integer = 1
Public Const     CAOUT_HIGH                  As Integer = 2
Public Const     CAOUT_CDM                   As Integer = 3
Public Const     CAOUT_OT                    As Integer = 4
Public Const     CAOUT_KW                    As Integer = 5
Public Const     CAOUT_TRIG                  As Integer = 6
Public Const     CAOUT_CLK                   As Integer = 7
Public Const     CAOUT_KW60                  As Integer = 8
Public Const     CAOUT_KWGAP                 As Integer = 9
Public Const     CAOUT_TRDLY                 As Integer = 10
Public Const     CAOUT_INVERT                As Integer = 16



' ----- Hardware registers (debug use only) -----
Public Const SPC_REG0x00                 As Integer = 900000
Public Const SPC_REG0x02                 As Integer = 900010
Public Const SPC_REG0x04                 As Integer = 900020
Public Const SPC_REG0x06                 As Integer = 900030
Public Const SPC_REG0x08                 As Integer = 900040
Public Const SPC_REG0x0A                 As Integer = 900050
Public Const SPC_REG0x0C                 As Integer = 900060
Public Const SPC_REG0x0E                 As Integer = 900070

Public Const SPC_DEBUGREG0               As Integer = 900100
Public Const SPC_DEBUGREG15              As Integer = 900115
Public Const SPC_DEBUGVALUE0             As Integer = 900200
Public Const SPC_DEBUGVALUE15            As Integer = 900215

Public Const SPC_MI_ISP                  As Integer = 901000
Public Const     ISP_TMS_0                   As Integer = 0
Public Const     ISP_TMS_1                   As Integer = 1
Public Const     ISP_TDO_0                   As Integer = 0
Public Const     ISP_TDO_1                   As Integer = 2


Public Const SPC_EE_RWAUTH               As Integer = 901100
Public Const SPC_EE_REG                  As Integer = 901110
Public Const SPC_EE_RESETCOUNTER         As Integer = 901120

' ----- Test Registers -----
Public Const SPC_TEST_BASE               As Integer = 902000
Public Const SPC_TEST_LOCAL_START        As Integer = 902100
Public Const SPC_TEST_LOCAL_END          As Integer = 902356
Public Const SPC_TEST_PLX_START          As Integer = 902400
Public Const SPC_TEST_PLX_END            As Integer = 902656
End Module


' end of file