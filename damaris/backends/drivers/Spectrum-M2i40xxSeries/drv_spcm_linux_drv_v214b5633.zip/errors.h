// ***********************************************************************
// errors.h: Old Spectrum error code header file. Has been changed in may
//           2004 to spcerr.h because errors.h has already been in use by
//           windows. 
//           Please change the include section of your project to include
//           spcerr.h directly.
// ***********************************************************************


#pragma message ("*** Please change include path from errors.h to spcerr.h ***")

#include "spcerr.h"
